# Smart Arranger

Smart Arranger is planned as a live AU MIDI arranger for Logic Pro. It will play imported style parts while the user performs chords on a MIDI keyboard.

The product requirements and compatibility target are in [Smart_Arranger.md](Smart_Arranger.md). The supplied interface image is a visual reference, not a final design specification.

## Current status

Stage 0 is in progress. A minimal JUCE MIDI passthrough prototype scaffold is now in `Source/`; it preserves incoming MIDI and intentionally does not generate accompaniment yet. It has not been compiled because JUCE and full Xcode are not available in the current workspace.

An initial GitHub Actions workflow is prepared in `.github/workflows/build-au.yml` to build an Intel AU and retain it as a downloadable artifact. It has not run because this project does not yet have a GitHub remote.

See [docs/environment-assessment.md](docs/environment-assessment.md) and [docs/compatibility-research.md](docs/compatibility-research.md) for observed setup, source findings, and remaining host checks.

## Compatibility target

- Required: Intel x86_64, macOS High Sierra 10.13, Logic Pro 10.4.4
- Development host observed: Apple Silicon Mac, macOS 15 (Darwin 24)
- Candidate framework: JUCE, pending compatibility validation

## Project rule

Do not claim support for a style format, AU MIDI routing behavior, or target OS until it has been verified with real files and on the target setup.
