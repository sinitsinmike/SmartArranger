#include "PluginProcessor.h"
#include "PluginEditor.h"

SmartArrangerAudioProcessor::SmartArrangerAudioProcessor()
    : juce::AudioProcessor (juce::AudioProcessor::BusesProperties())
{
}

void SmartArrangerAudioProcessor::prepareToPlay (double, int) {}
void SmartArrangerAudioProcessor::releaseResources() {}

void SmartArrangerAudioProcessor::processBlock (juce::AudioBuffer<float>& audio,
                                                 juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    juce::ignoreUnused (midi);

    // Stage 0 proof of life: preserve incoming MIDI unchanged. The prototype
    // intentionally generates no notes and makes no routing claims.
    audio.clear();
}

juce::AudioProcessorEditor* SmartArrangerAudioProcessor::createEditor()
{
    return new SmartArrangerAudioProcessorEditor (*this);
}

bool SmartArrangerAudioProcessor::hasEditor() const { return true; }
const juce::String SmartArrangerAudioProcessor::getName() const { return JucePlugin_Name; }
bool SmartArrangerAudioProcessor::acceptsMidi() const { return true; }
bool SmartArrangerAudioProcessor::producesMidi() const { return true; }
bool SmartArrangerAudioProcessor::isMidiEffect() const { return true; }
double SmartArrangerAudioProcessor::getTailLengthSeconds() const { return 0.0; }

int SmartArrangerAudioProcessor::getNumPrograms() { return 1; }
int SmartArrangerAudioProcessor::getCurrentProgram() { return 0; }
void SmartArrangerAudioProcessor::setCurrentProgram (int) {}
const juce::String SmartArrangerAudioProcessor::getProgramName (int) { return {}; }
void SmartArrangerAudioProcessor::changeProgramName (int, const juce::String&) {}

void SmartArrangerAudioProcessor::getStateInformation (juce::MemoryBlock&) {}
void SmartArrangerAudioProcessor::setStateInformation (const void*, int) {}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new SmartArrangerAudioProcessor();
}
