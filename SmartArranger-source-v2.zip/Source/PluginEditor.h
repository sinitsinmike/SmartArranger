#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"

class SmartArrangerAudioProcessorEditor final : public juce::AudioProcessorEditor
{
public:
    explicit SmartArrangerAudioProcessorEditor (SmartArrangerAudioProcessor& processor);
    void paint (juce::Graphics& graphics) override;

private:
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (SmartArrangerAudioProcessorEditor)
};
