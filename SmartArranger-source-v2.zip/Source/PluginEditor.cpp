#include "PluginEditor.h"

SmartArrangerAudioProcessorEditor::SmartArrangerAudioProcessorEditor (
    SmartArrangerAudioProcessor& processor)
    : juce::AudioProcessorEditor (processor)
{
    setSize (520, 260);
}

void SmartArrangerAudioProcessorEditor::paint (juce::Graphics& graphics)
{
    graphics.fillAll (juce::Colour::fromRGB (16, 22, 30));
    graphics.setColour (juce::Colour::fromRGB (232, 237, 243));
    graphics.setFont (juce::Font (26.0f, juce::Font::bold));
    graphics.drawFittedText ("SMART ARRANGER", getLocalBounds().reduced (24, 40),
                             juce::Justification::centredTop, 1);
    graphics.setColour (juce::Colour::fromRGB (168, 185, 199));
    graphics.setFont (juce::Font (15.0f));
    graphics.drawFittedText ("MIDI Effect Prototype  |  MIDI passes through unchanged",
                             getLocalBounds().reduced (24, 100),
                             juce::Justification::centredTop, 2);
}
