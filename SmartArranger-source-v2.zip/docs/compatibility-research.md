# Stage 0 research notes

These findings come from primary Apple/JUCE sources and require an on-machine host test before they are treated as project guarantees.

## Build target

- Xcode 14 release notes say the lowest supported deployment target is macOS 10.13: [Apple Xcode 14 release notes](https://developer.apple.com/documentation/xcode-release-notes/xcode-14-release-notes).
- JUCE's project currently documents a modern development setup and macOS runtime target lower than 10.13, while JUCE 7.0.3 changed Projucer's default deployment target to 10.13: [JUCE repository](https://github.com/juce-framework/JUCE), [JUCE breaking changes](https://github.com/juce-framework/JUCE/blob/master/BREAKING_CHANGES.md).
- This suggests a 10.13 target may be viable, but it does not prove the selected JUCE/Xcode/SDK combination will build on this Apple Silicon host or load in Logic 10.4.4 on High Sierra.
- Current host has Command Line Tools 15.3 but no full Xcode selected. JUCE is not installed in the workspace.
- JUCE 9.0.4 declares its deployment target down to macOS 10.11, so the project's macOS 10.13 target is within that stated range. JUCE is dual-licensed under AGPLv3 and a commercial licence; resolve the applicable licence before distribution: [JUCE 9.0.4 licence](https://github.com/juce-framework/JUCE/blob/9.0.4/LICENSE.md).

## Logic MIDI path

- Apple's Logic effects guide documents MIDI plug-ins processing MIDI and sending events onward to the software instrument on the channel strip: [Logic Pro Effects Guide](https://help.apple.com/pdf/logicpromac-effects/en_US/logic-pro-mac-effects-user-guide.pdf).
- Apple's release notes list recording MIDI plug-in output as a feature added in Logic 10.7.5: [Logic Pro release notes](https://support.apple.com/en-us/109503).
- Therefore live accompaniment through a single instrument appears aligned with MIDI FX. Recording the generated output in Logic 10.4.4, and routing independent parts to separate tracks, remain unverified and are likely constrained. MIDI channel numbers alone do not prove separate DAW tracks.
- MIDI Learn/parameter assignment in the exact target Logic version still needs a direct test.

## Prototype acceptance checks

1. Build AU for x86_64 with macOS 10.13 deployment target.
2. Validate plug-in scan and load in Logic Pro 10.4.4 on Intel High Sierra.
3. Confirm incoming MIDI passes to an instrument without timing faults.
4. Check generated MIDI playback, recording to a region, and separate-part routing as distinct tests.
5. Verify controller assignment for at least one automatable parameter/command.
