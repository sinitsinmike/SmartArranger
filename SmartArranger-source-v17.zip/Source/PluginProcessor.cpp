#include "PluginProcessor.h"
#include "PluginEditor.h"

#include <algorithm>
#include <cmath>

SmartArrangerAudioProcessor::SmartArrangerAudioProcessor()
    : juce::AudioProcessor (juce::AudioProcessor::BusesProperties()),
      parameters (*this, nullptr, "SMART_ARRANGER_STATE", createParameterLayout())
{
    accompanimentEnabledParameter = parameters.getRawParameterValue ("accompanimentEnabled");
}

juce::AudioProcessorValueTreeState::ParameterLayout
SmartArrangerAudioProcessor::createParameterLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;
    layout.add (std::make_unique<juce::AudioParameterBool> (
        juce::ParameterID { "accompanimentEnabled", 1 }, "Accompaniment", false));
    return layout;
}

void SmartArrangerAudioProcessor::prepareToPlay (double, int)
{
    heldNotes.fill (0);
    activeGeneratedNotes.fill (255);
    lastGeneratedStep = -1;
    detectedChordRoot.store (-1, std::memory_order_relaxed);
    detectedChordQuality.store (noChord, std::memory_order_relaxed);
    activeStyleNotes.fill (0);
    styleWasPlaying = false;
    styleBufferInUse = -1;
}

void SmartArrangerAudioProcessor::releaseResources()
{
    heldNotes.fill (0);
    activeGeneratedNotes.fill (255);
    lastGeneratedStep = -1;
    detectedChordRoot.store (-1, std::memory_order_relaxed);
    detectedChordQuality.store (noChord, std::memory_order_relaxed);
    activeStyleNotes.fill (0);
    styleWasPlaying = false;
    styleBufferInUse = -1;
}

bool SmartArrangerAudioProcessor::setLoadedStyle (const SmartArrangerStyleInfo& style,
                                                   int sectionIndex,
                                                   juce::String& error,
                                                   const juce::File& sourceFile)
{
    error.clear();
    if (style.ticksPerQuarter <= 0 || sectionIndex < 0
        || sectionIndex >= static_cast<int> (style.sections.size()))
    {
        error = "У выбранной секции нет корректной временной сетки.";
        return false;
    }

    const auto& section = style.sections[static_cast<size_t> (sectionIndex)];
    uint64_t lengthTicks = section.lengthTicks;
    if (lengthTicks == 0 && style.totalTicks > section.startTick)
        lengthTicks = style.totalTicks - section.startTick;
    if (lengthTicks == 0)
    {
        error = "Не удалось определить длительность секции.";
        return false;
    }

    StylePlaybackData next;
    next.sectionLengthTicks = lengthTicks;
    next.ticksPerQuarter = style.ticksPerQuarter;
    const auto sectionEnd = section.startTick + lengthTicks;
    for (const auto& event : style.events)
    {
        const bool fallbackTrack = section.name == "Track" && event.sectionIndex < 0;
        if (! fallbackTrack && event.sectionIndex != sectionIndex)
            continue;
        if (event.tick < section.startTick || event.tick >= sectionEnd)
            continue;
        auto normalized = event;
        normalized.tick -= section.startTick;
        next.events.push_back (normalized);
    }

    if (next.events.empty())
    {
        error = "В выбранной секции не найдено MIDI-событий.";
        return false;
    }

    const int current = activeStyleBuffer.load (std::memory_order_acquire);
    const int target = current == 0 ? 1 : 0;
    while (styleReaders[static_cast<size_t> (target)].load (std::memory_order_acquire) != 0)
        juce::Thread::sleep (1);

    stylePlaybackBuffers[static_cast<size_t> (target)] = std::move (next);
    activeStyleBuffer.store (target, std::memory_order_release);
    parameters.state.setProperty ("stylePath", sourceFile.getFullPathName(), nullptr);
    parameters.state.setProperty ("styleSection", sectionIndex, nullptr);
    return true;
}

juce::String SmartArrangerAudioProcessor::getStoredStylePath() const
{
    return parameters.state.getProperty ("stylePath").toString();
}

int SmartArrangerAudioProcessor::getStoredStyleSection() const noexcept
{
    return static_cast<int> (parameters.state.getProperty ("styleSection", 0));
}

void SmartArrangerAudioProcessor::clearLoadedStyle (bool clearSavedSelection) noexcept
{
    activeStyleBuffer.store (-1, std::memory_order_release);
    if (clearSavedSelection)
    {
        parameters.state.removeProperty ("stylePath", nullptr);
        parameters.state.removeProperty ("styleSection", nullptr);
    }
}

void SmartArrangerAudioProcessor::processBlock (juce::AudioBuffer<float>& audio,
                                                 juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    audio.clear();

    // Pass MIDI through unchanged while observing held notes for chord
    // recognition. State is maintained per channel and key, including the
    // velocity-zero Note On form of Note Off.
    for (const auto metadata : midi)
    {
        const auto& message = metadata.getMessage();
        if (! message.isNoteOn() && ! message.isNoteOff())
            continue;

        const int note = message.getNoteNumber();
        const int channel = message.getChannel() - 1;
        if (note < 0 || note >= 128 || channel < 0 || channel >= 16)
            continue;

        heldNotes[static_cast<size_t> (channel * 128 + note)] = message.isNoteOn() ? 1 : 0;
        updateDetectedChord();
    }

    renderAccompaniment (midi, audio.getNumSamples());
}

namespace
{
struct ChordPattern
{
    SmartArrangerAudioProcessor::ChordQuality quality;
    uint16_t intervals;
};

constexpr ChordPattern chordPatterns[] =
{
    { SmartArrangerAudioProcessor::major,                 (1u << 0) | (1u << 4) | (1u << 7) },
    { SmartArrangerAudioProcessor::minor,                 (1u << 0) | (1u << 3) | (1u << 7) },
    { SmartArrangerAudioProcessor::diminished,            (1u << 0) | (1u << 3) | (1u << 6) },
    { SmartArrangerAudioProcessor::augmented,             (1u << 0) | (1u << 4) | (1u << 8) },
    { SmartArrangerAudioProcessor::suspendedSecond,       (1u << 0) | (1u << 2) | (1u << 7) },
    { SmartArrangerAudioProcessor::suspendedFourth,       (1u << 0) | (1u << 5) | (1u << 7) },
    { SmartArrangerAudioProcessor::dominantSeventh,       (1u << 0) | (1u << 4) | (1u << 7) | (1u << 10) },
    { SmartArrangerAudioProcessor::majorSeventh,          (1u << 0) | (1u << 4) | (1u << 7) | (1u << 11) },
    { SmartArrangerAudioProcessor::minorSeventh,          (1u << 0) | (1u << 3) | (1u << 7) | (1u << 10) },
    { SmartArrangerAudioProcessor::halfDiminishedSeventh, (1u << 0) | (1u << 3) | (1u << 6) | (1u << 10) },
    { SmartArrangerAudioProcessor::diminishedSeventh,     (1u << 0) | (1u << 3) | (1u << 6) | (1u << 9) }
};

int countBits (uint16_t bits) noexcept
{
    int count = 0;
    while (bits != 0)
    {
        count += bits & 1u;
        bits >>= 1;
    }
    return count;
}
}

void SmartArrangerAudioProcessor::updateDetectedChord() noexcept
{
    uint16_t pitchClasses = 0;
    int lowestNote = 128;
    for (int channel = 0; channel < 16; ++channel)
    {
        for (int note = 0; note < 128; ++note)
        {
            if (heldNotes[static_cast<size_t> (channel * 128 + note)] == 0)
                continue;

            pitchClasses |= static_cast<uint16_t> (1u << (note % 12));
            lowestNote = juce::jmin (lowestNote, note);
        }
    }

    if (countBits (pitchClasses) < 3)
    {
        // Hold the latest recognized chord after its input notes are released.
        // This is how a style arranger sustains the harmony between changes.
        return;
    }

    int bestScore = 1000;
    int bestRoot = -1;
    ChordQuality bestQuality = noChord;
    const int bassPitchClass = lowestNote % 12;

    for (int root = 0; root < 12; ++root)
    {
        for (const auto& pattern : chordPatterns)
        {
            uint16_t transposed = 0;
            for (int interval = 0; interval < 12; ++interval)
                if ((pattern.intervals & (1u << interval)) != 0)
                    transposed |= static_cast<uint16_t> (1u << ((root + interval) % 12));

            const int missing = countBits (static_cast<uint16_t> (transposed & ~pitchClasses));
            const int extra = countBits (static_cast<uint16_t> (pitchClasses & ~transposed));
            const int matched = countBits (static_cast<uint16_t> (transposed & pitchClasses));
            if (matched < 3)
                continue;

            const int score = missing * 4 + extra * 2 + (root == bassPitchClass ? 0 : 1);
            if (score < bestScore)
            {
                bestScore = score;
                bestRoot = root;
                bestQuality = pattern.quality;
            }
        }
    }

    if (bestScore >= 1000)
    {
        detectedChordRoot.store (-1, std::memory_order_relaxed);
        detectedChordQuality.store (noChord, std::memory_order_relaxed);
        return;
    }

    detectedChordRoot.store (bestRoot, std::memory_order_relaxed);
    detectedChordQuality.store (bestQuality, std::memory_order_relaxed);
}

void SmartArrangerAudioProcessor::renderAccompaniment (juce::MidiBuffer& midi,
                                                        int blockSamples) noexcept
{
    const auto sendNoteOffs = [&] (int samplePosition)
    {
        for (auto& note : activeGeneratedNotes)
        {
            if (note != 255)
            {
                midi.addEvent (juce::MidiMessage::noteOff (1, note), samplePosition);
                note = 255;
            }
        }
    };

    if (activeStyleBuffer.load (std::memory_order_acquire) < 0 && styleWasPlaying)
    {
        for (int channel = 0; channel < 16; ++channel)
            for (int note = 0; note < 128; ++note)
            {
                const auto index = static_cast<size_t> (channel * 128 + note);
                if (activeStyleNotes[index] != 0)
                {
                    midi.addEvent (juce::MidiMessage::noteOff (channel + 1, note), 0);
                    activeStyleNotes[index] = 0;
                }
            }
        styleWasPlaying = false;
        styleBufferInUse = -1;
    }

    if (renderLoadedStyle (midi, blockSamples))
    {
        sendNoteOffs (0);
        lastGeneratedStep = -1;
        return;
    }

    if (! isAccompanimentEnabled() || blockSamples <= 0)
    {
        sendNoteOffs (0);
        lastGeneratedStep = -1;
        return;
    }

    auto* playHead = getPlayHead();
    if (playHead == nullptr)
    {
        sendNoteOffs (0);
        lastGeneratedStep = -1;
        return;
    }

    const auto position = playHead->getPosition();
    if (! position.hasValue() || ! position->getIsPlaying())
    {
        sendNoteOffs (0);
        lastGeneratedStep = -1;
        return;
    }

    const auto ppqPosition = position->getPpqPosition();
    const auto bpmValue = position->getBpm();
    if (! ppqPosition.hasValue() || ! bpmValue.hasValue() || *bpmValue <= 0.0
        || getSampleRate() <= 0.0)
    {
        sendNoteOffs (0);
        lastGeneratedStep = -1;
        return;
    }

    const double ppqStart = *ppqPosition;
    const double ppqPerBlock = static_cast<double> (blockSamples) * *bpmValue
                             / (60.0 * getSampleRate());
    int numerator = 4;
    int denominator = 4;
    if (const auto signature = position->getTimeSignature())
    {
        const auto validDenominator = signature->denominator == 1 || signature->denominator == 2
                                   || signature->denominator == 4 || signature->denominator == 8
                                   || signature->denominator == 16 || signature->denominator == 32;
        if (signature->numerator > 0 && signature->numerator <= 32 && validDenominator)
        {
            numerator = signature->numerator;
            denominator = signature->denominator;
        }
    }
    const int stepsPerBar = numerator * 2;
    const double stepPpq = 2.0 / denominator;
    const auto firstStep = static_cast<int64_t> (std::ceil (ppqStart / stepPpq - 1.0e-9));
    const auto lastStep = static_cast<int64_t> (std::floor ((ppqStart + ppqPerBlock) / stepPpq - 1.0e-9));

    if (firstStep < lastGeneratedStep)
    {
        sendNoteOffs (0);
        lastGeneratedStep = firstStep - 1;
    }

    const int root = detectedChordRoot.load (std::memory_order_relaxed);
    const int quality = detectedChordQuality.load (std::memory_order_relaxed);
    if (root < 0 || root > 11)
    {
        sendNoteOffs (0);
        lastGeneratedStep = lastStep;
        return;
    }

    int third = 4;
    int fifth = 7;
    switch (quality)
    {
        case minor: case minorSeventh: case halfDiminishedSeventh: case diminishedSeventh:
            third = 3; break;
        case augmented: fifth = 8; break;
        case suspendedSecond: third = 2; break;
        case suspendedFourth: third = 5; break;
        default: break;
    }
    if (quality == diminished || quality == halfDiminishedSeventh || quality == diminishedSeventh)
        fifth = 6;

    int seventh = -1;
    if (quality == dominantSeventh || quality == minorSeventh || quality == halfDiminishedSeventh)
        seventh = 10;
    else if (quality == majorSeventh)
        seventh = 11;
    else if (quality == diminishedSeventh)
        seventh = 9;

    const int bassHalfBarStep = stepsPerBar / 2;
    const int firstChordStep = juce::jlimit (1, stepsPerBar - 1,
        static_cast<int> (std::llround (stepsPerBar * 0.25)));
    const int secondChordStep = juce::jlimit (1, stepsPerBar - 1,
        static_cast<int> (std::llround (stepsPerBar * 0.75)));
    for (auto step = juce::jmax (firstStep, lastGeneratedStep + 1);
         step <= lastStep; ++step)
    {
        const double eventPpq = static_cast<double> (step) * stepPpq;
        const int samplePosition = juce::jlimit (0, blockSamples - 1,
            static_cast<int> (std::llround ((eventPpq - ppqStart) * 60.0 * getSampleRate() / *bpmValue)));
        sendNoteOffs (samplePosition);

        int stepInBar = static_cast<int> (step % stepsPerBar);
        if (stepInBar < 0)
            stepInBar += stepsPerBar;
        const auto addGenerated = [&] (int note, int velocity)
        {
            note = juce::jlimit (0, 127, note);
            midi.addEvent (juce::MidiMessage::noteOn (1, note, static_cast<juce::uint8> (velocity)),
                           samplePosition);
            for (auto& active : activeGeneratedNotes)
                if (active == 255)
                {
                    active = static_cast<uint8_t> (note);
                    break;
                }
        };

        // The demonstration pattern follows the host's time-signature grid.
        // Bass marks the bar start and midpoint; chord stabs fall at quarter-bar points.
        if (stepInBar == 0 || stepInBar == bassHalfBarStep)
            addGenerated (36 + root, 92);

        if (stepInBar == firstChordStep || stepInBar == secondChordStep)
        {
            addGenerated (60 + root, 78);
            addGenerated (60 + ((root + third) % 12), 74);
            addGenerated (60 + ((root + fifth) % 12), 74);
            if (seventh >= 0)
                addGenerated (60 + ((root + seventh) % 12), 68);
        }

        lastGeneratedStep = step;
    }
}

bool SmartArrangerAudioProcessor::renderLoadedStyle (juce::MidiBuffer& midi,
                                                       int blockSamples) noexcept
{
    int slot = -1;
    const StylePlaybackData* style = nullptr;
    for (;;)
    {
        slot = activeStyleBuffer.load (std::memory_order_acquire);
        if (slot < 0 || slot > 1)
            return false;
        styleReaders[static_cast<size_t> (slot)].fetch_add (1, std::memory_order_acq_rel);
        if (activeStyleBuffer.load (std::memory_order_acquire) == slot)
        {
            style = &stylePlaybackBuffers[static_cast<size_t> (slot)];
            break;
        }
        styleReaders[static_cast<size_t> (slot)].fetch_sub (1, std::memory_order_release);
    }

    const auto releaseReader = [this, slot]
    {
        styleReaders[static_cast<size_t> (slot)].fetch_sub (1, std::memory_order_release);
    };
    const auto sendStyleNoteOffs = [this, &midi] (int samplePosition)
    {
        for (int channel = 0; channel < 16; ++channel)
            for (int note = 0; note < 128; ++note)
            {
                const auto index = static_cast<size_t> (channel * 128 + note);
                if (activeStyleNotes[index] != 0)
                {
                    midi.addEvent (juce::MidiMessage::noteOff (channel + 1, note), samplePosition);
                    activeStyleNotes[index] = 0;
                }
            }
    };

    if (! isAccompanimentEnabled() || blockSamples <= 0)
    {
        sendStyleNoteOffs (0);
        styleWasPlaying = false;
        styleBufferInUse = -1;
        lastStyleBlockEndPpq = 0.0;
        releaseReader();
        return true;
    }

    auto* playHead = getPlayHead();
    if (playHead == nullptr)
    {
        sendStyleNoteOffs (0);
        styleWasPlaying = false;
        styleBufferInUse = -1;
        lastStyleBlockEndPpq = 0.0;
        releaseReader();
        return true;
    }

    const auto position = playHead->getPosition();
    if (! position.hasValue() || ! position->getIsPlaying())
    {
        sendStyleNoteOffs (0);
        styleWasPlaying = false;
        styleBufferInUse = -1;
        lastStyleBlockEndPpq = 0.0;
        releaseReader();
        return true;
    }

    const auto ppqPosition = position->getPpqPosition();
    const auto bpmValue = position->getBpm();
    if (! ppqPosition.hasValue() || ! bpmValue.hasValue() || *bpmValue <= 0.0
        || getSampleRate() <= 0.0 || style->ticksPerQuarter <= 0
        || style->sectionLengthTicks == 0)
    {
        sendStyleNoteOffs (0);
        styleWasPlaying = false;
        styleBufferInUse = -1;
        lastStyleBlockEndPpq = 0.0;
        releaseReader();
        return true;
    }

    const double ppqStart = *ppqPosition;
    const double ppqPerBlock = static_cast<double> (blockSamples) * *bpmValue
                             / (60.0 * getSampleRate());
    const double ppqEnd = ppqStart + ppqPerBlock;
    const double sectionLengthPpq = static_cast<double> (style->sectionLengthTicks)
                                  / style->ticksPerQuarter;
    if (styleWasPlaying && (std::abs (ppqStart - lastStyleBlockEndPpq) > 0.02
                            || styleBufferInUse != slot))
        sendStyleNoteOffs (0);
    styleWasPlaying = true;
    styleBufferInUse = slot;

    const auto firstCycle = static_cast<int64_t> (std::floor (ppqStart / sectionLengthPpq));
    const auto lastCycle = static_cast<int64_t> (std::floor ((ppqEnd - 1.0e-12) / sectionLengthPpq));
    for (int64_t cycle = firstCycle; cycle <= lastCycle; ++cycle)
    {
        const double cycleStart = static_cast<double> (cycle) * sectionLengthPpq;
        const double segmentStart = juce::jmax (ppqStart, cycleStart);
        const double segmentEnd = juce::jmin (ppqEnd, cycleStart + sectionLengthPpq);
        if (segmentEnd <= segmentStart)
            continue;

        if (segmentStart <= cycleStart + 1.0e-12 && cycle != firstCycle)
            sendStyleNoteOffs (juce::jlimit (0, blockSamples - 1,
                static_cast<int> (std::llround ((cycleStart - ppqStart) * 60.0
                                                * getSampleRate() / *bpmValue))));

        const auto firstTick = static_cast<uint64_t> (juce::jmax (0.0,
            std::ceil ((segmentStart - cycleStart) * style->ticksPerQuarter - 1.0e-9)));
        const auto endTick = (segmentEnd >= cycleStart + sectionLengthPpq - 1.0e-12)
            ? style->sectionLengthTicks
            : static_cast<uint64_t> (juce::jmax (0.0,
                std::ceil ((segmentEnd - cycleStart) * style->ticksPerQuarter - 1.0e-9)));
        auto event = std::lower_bound (style->events.begin(), style->events.end(), firstTick,
            [] (const SmartArrangerStyleEvent& candidate, uint64_t tick)
            {
                return candidate.tick < tick;
            });

        for (; event != style->events.end() && event->tick < endTick; ++event)
        {
            const double eventPpq = cycleStart
                                  + static_cast<double> (event->tick) / style->ticksPerQuarter;
            const int samplePosition = juce::jlimit (0, blockSamples - 1,
                static_cast<int> (std::llround ((eventPpq - ppqStart) * 60.0
                                                * getSampleRate() / *bpmValue)));
            const auto command = static_cast<uint8_t> (event->status & 0xf0u);
            const int channel = static_cast<int> (event->status & 0x0fu);
            if (event->dataBytes == 1)
                midi.addEvent (juce::MidiMessage (event->status, event->data1), samplePosition);
            else
                midi.addEvent (juce::MidiMessage (event->status, event->data1, event->data2),
                               samplePosition);

            if (command == 0x90u && event->data2 != 0)
                activeStyleNotes[static_cast<size_t> (channel * 128 + event->data1)] = 1;
            else if (command == 0x80u || (command == 0x90u && event->data2 == 0))
                activeStyleNotes[static_cast<size_t> (channel * 128 + event->data1)] = 0;
        }
    }

    lastStyleBlockEndPpq = ppqEnd;
    releaseReader();
    return true;
}

int SmartArrangerAudioProcessor::getDetectedChordRoot() const noexcept
{
    return detectedChordRoot.load (std::memory_order_relaxed);
}

int SmartArrangerAudioProcessor::getDetectedChordQuality() const noexcept
{
    return detectedChordQuality.load (std::memory_order_relaxed);
}

void SmartArrangerAudioProcessor::setAccompanimentEnabled (bool shouldEnable) noexcept
{
    if (auto* parameter = parameters.getParameter ("accompanimentEnabled"))
        parameter->setValueNotifyingHost (shouldEnable ? 1.0f : 0.0f);
}

bool SmartArrangerAudioProcessor::isAccompanimentEnabled() const noexcept
{
    return accompanimentEnabledParameter != nullptr
        && accompanimentEnabledParameter->load (std::memory_order_relaxed) >= 0.5f;
}

juce::AudioProcessorValueTreeState& SmartArrangerAudioProcessor::getParameterState() noexcept
{
    return parameters;
}

juce::AudioProcessorEditor* SmartArrangerAudioProcessor::createEditor()
{
    return new SmartArrangerAudioProcessorEditor (*this);
}

bool SmartArrangerAudioProcessor::hasEditor() const { return true; }
const juce::String SmartArrangerAudioProcessor::getName() const { return JucePlugin_Name; }
bool SmartArrangerAudioProcessor::acceptsMidi() const { return true; }
bool SmartArrangerAudioProcessor::producesMidi() const { return true; }
bool SmartArrangerAudioProcessor::isMidiEffect() const { return true; }
double SmartArrangerAudioProcessor::getTailLengthSeconds() const { return 0.0; }

int SmartArrangerAudioProcessor::getNumPrograms() { return 1; }
int SmartArrangerAudioProcessor::getCurrentProgram() { return 0; }
void SmartArrangerAudioProcessor::setCurrentProgram (int) {}
const juce::String SmartArrangerAudioProcessor::getProgramName (int) { return {}; }
void SmartArrangerAudioProcessor::changeProgramName (int, const juce::String&) {}

void SmartArrangerAudioProcessor::getStateInformation (juce::MemoryBlock& destination)
{
    if (const auto xml = parameters.copyState().createXml())
        copyXmlToBinary (*xml, destination);
}

void SmartArrangerAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (const auto xml = getXmlFromBinary (data, sizeInBytes))
        if (xml->hasTagName (parameters.state.getType().toString()))
        {
            parameters.replaceState (juce::ValueTree::fromXml (*xml));

            const juce::File styleFile (getStoredStylePath());
            if (styleFile.existsAsFile())
            {
                SmartArrangerStyleInfo style;
                juce::String error;
                const int savedSection = getStoredStyleSection();
                if (SmartArrangerStyleFile::inspect (styleFile, style, error)
                    && savedSection >= 0
                    && savedSection < static_cast<int> (style.sections.size()))
                    setLoadedStyle (style, savedSection, error, styleFile);
            }
            else
            {
                clearLoadedStyle (false);
            }
        }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new SmartArrangerAudioProcessor();
}
