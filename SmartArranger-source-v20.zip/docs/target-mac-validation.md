# Target Mac validation checklist

Target confirmed by the user: Intel MacBook, macOS High Sierra 10.13, Logic Pro 10.4.4.

Codex does not need to be installed on that computer. Source and/or the built AU can be transferred from the development machine. The target Mac is the acceptance environment for plugin loading and host behavior.

Additional observation: the user loaded the Intel AU in Logic Pro on an Apple Silicon Mac and shared a screenshot showing the plug-in window. This confirms AU discovery and opening in that setup, but does not identify whether Logic was running natively or through Rosetta. The AU architecture remains x86_64 only; no native arm64 build has been verified.

## First prototype checks

1. Confirm the Mac's processor is Intel and record the exact macOS build.
2. Install/copy the AU component to `~/Library/Audio/Plug-Ins/Components` after build.
3. Open Logic Pro 10.4.4 and confirm Smart Arranger appears as a MIDI FX insert.
4. Insert it before a software instrument and confirm keyboard/region MIDI reaches the instrument.
5. Check project reopen, plugin rescan, and whether Logic reports compatibility/signing errors.
6. In a later generated-MIDI prototype, test playback, recording, and part routing separately; passing MIDI through is not proof of those features.
