#pragma once

#include <JuceHeader.h>
#include <cstdint>
#include <vector>

struct SmartArrangerStyleSection
{
    juce::String name;
    uint64_t startTick = 0;
    uint64_t lengthTicks = 0;
};

struct SmartArrangerStyleEvent
{
    uint64_t tick = 0;
    int sectionIndex = -1;
    uint8_t status = 0;
    uint8_t data1 = 0;
    uint8_t data2 = 0;
    uint8_t dataBytes = 0;
};

struct SmartArrangerStyleInfo
{
    juce::String name;
    juce::String format;
    int tempo = 120;
    int numerator = 4;
    int denominator = 4;
    int ticksPerQuarter = 0;
    uint64_t totalTicks = 0;
    uint16_t usedChannels = 0;
    bool hasCasm = false;
    std::vector<SmartArrangerStyleSection> sections;
    std::vector<SmartArrangerStyleEvent> events;
};

class SmartArrangerStyleFile
{
public:
    static bool inspect (const juce::File& file,
                         SmartArrangerStyleInfo& result,
                         juce::String& error);
};
