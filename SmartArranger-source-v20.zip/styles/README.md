# Official style library

This folder is reserved for style assets whose source and redistribution rights have been confirmed. No Yamaha style binaries are included yet.

Yamaha's official expansion pages provide model-specific packs for the PSR-SX900 and PSR-S950, but Yamaha's S950 download license states that the software/data is non-transferable and may not be distributed or shared over a network. Keep downloaded vendor packs outside this repository and load supported files locally. Do not bundle them in the AU or publish them in Git without explicit redistribution permission.

The sample archives supplied for development are unverified third-party/user material. They are not designated as defaults and are not included in this folder.
