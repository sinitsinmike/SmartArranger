# Yamaha style behavior research notes

Status: preliminary source review. This is a research note, not a complete behavioral specification. No Yamaha-specific playback behavior should be considered implemented based on this note alone.

## Official references

- [PSR-SX900/SX700 Owner's Manual](https://data.yamaha.com/files/download/other_assets/1/1279261/psrsx900_en_om_b0.pdf)
- [PSR-SX900/SX700 Reference Manual](https://data.yamaha.com/files/download/other_assets/7/1279207/psrsx900_en_rm_b0.pdf)
- [PSR-S950/S750 Reference Manual](https://data.yamaha.com/files/download/other_assets/7/328237/psrs950_en_rm_a0.pdf)
- [Yamaha MIDI Song to Style](https://usa.yamaha.com/products/musical_instruments/keyboards/apps/midisong_to_style/index.html)
- [Yamaha MIDI Song to Style Owner's Manual](https://data.yamaha.com/files/download/other_assets/4/2179884/MIDI_Song_to_Style_owners_manual_En_B0.pdf)

## Related arranger software and authoring tools

- [One Man Band feature list](https://www.1manband.nl/features.htm) explicitly claims playback of Yamaha styles, live/sequenced operation, full-fingered and single-finger chord recognition, slash-chord recognition, free-form recognition, glitch-free style loading, real-time performance recording, and style editing/creation. This makes it a useful independent behavioral reference or possible test comparator. The public feature list does not specify exact chord-change quantization, Intro-to-Main scheduling, or note-off rules, so those details must not be copied as Yamaha facts. The listed compatibility is old Windows-era support; do not assume it runs on the user's current macOS.
- [Band-in-a-Box 2025 User's Guide, Chapter 15](https://www.pgmusic.com/manuals/bbw2025full/chapter15.htm) describes its own `.STY` style workflow and StyleMaker operations, including creating a BIAB style from MIDI. The shared `.STY` extension does not mean its style data is Yamaha SFF. BIAB can be useful as a general accompaniment/recording comparison, but it is not evidence for Yamaha CASM or hardware transition behavior.
- Yamaha's [MIDI Song to Style app](https://usa.yamaha.com/products/musical_instruments/keyboards/apps/midisong_to_style/index.html) and [owner's manual](https://data.yamaha.com/files/download/other_assets/4/2179884/MIDI_Song_to_Style_owners_manual_En_B0.pdf) are official Yamaha authoring resources for converting MIDI songs into Yamaha style files. They are useful for studying the supported authoring workflow and validating generated file structure; they are not a public playback-engine developer specification.

No separate public Yamaha developer document that fully specifies runtime chord-change timing and section-transition scheduling has been located in this research pass. The official Style Creator/SFF Edit reference manuals remain the strongest published Yamaha sources found for authoring parameters; an instrument-level conformance check or direct Yamaha support response is still needed for undocumented runtime behavior.

## Independent implementation reference (not a Yamaha specification)

- [bures/sff2-tools](https://github.com/bures/sff2-tools) can convert SFF1/SFF2 files to a textual form and play selected section/channel data. Its README explicitly says its player ignores CASM channel mapping and note/chord transposition because the author lacked information on the exact behavior for different CASM settings. This is useful evidence about the gap in publicly available implementation guidance, but it is third-party reverse-engineering and must not be treated as Yamaha's normative specification.

## Local fixture structure observed (not verified as official Yamaha data)

Read-only inspection of five user-provided local fixtures found that CASM is not a single flat channel table: each file contains multiple length-prefixed `CSEG` records, with different record families present. The parser now preserves bounded raw CASM records and each CSEG's nested records, but it still does not interpret their playback semantics.

| Local fixture | CSEG records | CASM records observed inside CSEG payloads |
| --- | ---: | --- |
| `PopShuffle1.T161.bcs` | 2 | 26 `Ctb2` |
| `ClubBeat.T152.prs` | 3 | 19 `Ctb2` |
| `PopRock.T162.bcs` | 2 | 22 `Ctb2` |
| `BossaNova1.T110.prs` | 7 | 72 `Ctb2` |
| `MovieSwing1.S737.STY` | 2 | 28 `Ctab`, 28 `Cntt` |

This inventory is only evidence about those local files. Their provenance is unverified, so it does not establish Yamaha's complete CASM schema or that every field should be interpreted the same way. It does establish an implementation requirement: CASM parsing must respect nested chunk lengths, support both `Ctab` and `Ctb2` records, retain multiple `CSEG`s, and associate settings with their segment/channel context. Do not collapse a file to one global transpose setting.

## Confirmed from the public material reviewed so far

- Yamaha's reference manuals include Style Creator / SFF Edit material. This documents settings for Yamaha's Style File Format (SFF); it is more useful than treating a style as a collection of unqualified MIDI loops.
- The SX900 reference material describes a style as sections (such as Intro, Main, Ending) made from source patterns, and includes SFF-related playback settings.
- Yamaha documents NTR (Note Transposition Rule) and NTT (Note Transposition Table) settings for adapting source-pattern notes to the recognized chord. The current Smart Arranger's global C-major-based transform does not implement these per-part rules.
- In Style Creator guidance for Main/Fill-in, Yamaha's default Source Root/Chord is CM7 and the source pattern is authored against that reference so the arranger can adapt it to played chords. This describes how the pattern is prepared, not the runtime quantization point for a newly detected chord.
- The SX900 Owner's Manual says that, when AUTO FILL IN is enabled, pressing a MAIN VARIATION button during play invokes the Auto Fill In behavior.
- The same manual also says that pressing the already selected MAIN VARIATION again plays an appropriate Fill In pattern. This confirms that Fill In is a transition/accent action in normal playing, not merely another continuously looping variation. The retrieved wording does not establish the exact quantization point or behavior when Auto Fill In is disabled.
- In the SX900/SX700 and S950/S750 Reference Manuals' Style Creator guidance, Yamaha says Intro and Ending sections are designed assuming the chord will not change during playback. This is explicit authoring guidance and strongly informs intended use: a player should establish the harmony for these one-shot sections and let them run. It is not, by itself, a full specification of the playback engine's response if a chord is changed anyway.
- The SX900 Reference Manual describes recording Style playback with chord-change and section-change events. This is relevant to the future performance-recording design, but does not by itself specify Smart Arranger's Logic recording implementation.

## Still to verify directly in the manuals

- Exact timing and priority for pressing a different Main variation while a section is playing, with Auto Fill In both enabled and disabled.
- Whether selecting Main during an Intro queues, interrupts, or otherwise changes the current Intro on SX900 and S950.
- If a performer changes the detected chord during an Intro/Ending despite Yamaha's authoring assumption, whether the engine ignores the change, applies it at a boundary, or handles it per-part.
- Exact Fill In, Break, and Ending transitions, including the section button/lamp states and when each request is applied.
- The chord-fingering modes and detection boundaries that apply to SX900 and S950, including bass/inversion handling.
- How Yamaha emits note-offs and handles notes crossing pattern/section boundaries.
- Which behaviors are model-specific and which belong to the shared SFF playback model.

Until those items are verified from the relevant manual sections or tested on the target instruments, section scheduling and chord handling remain provisional. Do not describe the current prototype as Yamaha-compatible.

## Hardware verification protocol for unresolved runtime behavior

The public owner/reference manuals reviewed so far do not fully specify the runtime scheduler. If Yamaha does not publish a more detailed developer document, use repeatable observations on the target PSR-SX900/S950 as compatibility evidence. Record model, firmware, fingering mode, Auto Fill setting, tempo, meter, style filename, section, and exact button/key timestamps for every run.

| Question | Controlled probe | Record as evidence |
| --- | --- | --- |
| How often can harmony change in a looping Main? | Hold Main A; change between two unambiguous triads on successive beats, then at faster intervals; repeat with one note at a time and with the full chord held. | First audible onset that follows each chord, whether existing notes are cut or allowed to finish, and whether the result differs by part. |
| Does a requested Main wait for a musical boundary? | While Main A loops, press Main B at different points within the bar; repeat with Auto Fill In on and off. | Button/lamp response time, any Fill occurrence, exact boundary where B starts, and whether A completes its phrase/bar. |
| What happens when Main is requested during Intro? | Start the same Intro, press a Main variation at the beginning, middle, and near the end; repeat for each available Intro. | Whether Intro finishes, whether the request queues, which Main starts next, and whether Fill is inserted. |
| Does Intro follow a changed chord? | Start an Intro on a stable chord; change to a second stable chord at controlled beat positions; compare parts and repeat with several Intros. | Which parts change harmony, at what event/boundary, and whether already sounding notes receive a Note Off or finish naturally. |
| What do Fill, Break, and Ending requests do? | Trigger each from each available Main at several beat positions, with Auto Fill both ways where applicable. | Current section completion, transition pattern, next section, loop/one-shot status, and note-release behavior. |

Use a MIDI loopback or audio recording aligned to a metronome when available; screenshots or recollection alone are insufficient to distinguish an immediate response from a beat/bar-quantized one. Repeat each probe at least three times. Treat observations as model-specific until corroborated on both SX900 and S950. Do not infer exact firmware internals from audible output alone.

## Implementation gate

Do not implement chord debounce, beat/bar quantization, Intro chord locking, or section-request priority as a “Yamaha rule” until supported by a specific Yamaha manual passage or the verification protocol above. Keep the current once-per-bar chord snapshot and transition scheduler explicitly labeled as prototype behavior. After establishing the reference behavior, encode it as a table-driven scheduler with independent policies for (1) chord recognition, (2) harmony application, and (3) section request/transition; this avoids conflating “when a chord is detected” with “when a section can switch.”

## Current prototype audit (source inspection)

This is a description of the current local source, not a Yamaha rule:

- Incoming Note On/Off messages update the held-note set and chord detector for every MIDI event in the host audio block. There is no debounce or “wait for beat” stage in chord recognition.
- The detector only replaces its latched chord when it finds a chord pattern with at least three distinct pitch classes. When fewer than three remain, it keeps the last recognized chord.
- The loaded-style renderer snapshots that latched chord at the first style MIDI event it encounters in each host bar. Thus rapid chord input can update the detector several times, but the rendered style generally changes harmony at most once per bar. The final detected chord when the block is processed can win; the exact result can depend on host block/event timing.
- A harmony change at that bar boundary currently sends note-offs for active style notes and transforms notes with a simple global root/third/fifth map. It does not apply Yamaha's per-part CASM NTR/NTT settings.
- Section changes also currently send note-offs at the switch point. The queue/one-shot behavior visible in this source has not been validated against Yamaha manuals or hardware.
- Intro receives the same global chord transform as other sections. The source does not model a Yamaha-specific Intro chord policy.

These limitations mean “ten chords in one second” is not safely specified by the current prototype. Do not treat its once-per-bar sampling or note-off behavior as proof of Yamaha timing. A spec-aligned implementation needs the official rules for chord recognition/fingering, chord-change application points, CASM per-part transposition, and section-transition note handling first.
