# Smart Arranger skin concepts

The comparison board in [skin-variants-vintage-stage-neon.png](skin-variants-vintage-stage-neon.png) contains three visual directions:

- **A — Vintage:** graphite hardware panel with warm gold controls. Selected for the next implementation pass.
- **B — Stage:** clean navy interface with cyan accents.
- **C — Neon:** plum stage-console look with magenta and teal highlights.

[Original-mockup.png](Original-mockup.png) is the original full-featured reference supplied for the project.

[yamaha-arranger-skin-concept-2026-11.png](yamaha-arranger-skin-concept-2026-11.png) is a quick hardware-inspired concept based on the current plugin layout. It groups Intro A/B, aligns the grid inside the panel, and centers START/STOP beneath the section buttons. This is a visual proposal only; it has not been implemented in the plugin.

These are visual concepts, not screenshots of implemented plugin builds. The on-screen keyboard shown in the concepts is deferred to a later feature pass.
