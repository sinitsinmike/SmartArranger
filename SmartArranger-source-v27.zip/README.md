# Smart Arranger

Smart Arranger is an experimental AU MIDI effect for Logic Pro. It is being developed as a style-based live arranger: play chords on a MIDI keyboard and have accompaniment follow them.

## Implemented

- AU MIDI effect target for Logic Pro, built with JUCE 9.0.4.
- Passes incoming MIDI through and shows a preliminary live chord estimate.
- Loads a user-selected Yamaha-style file from disk and reads its title, tempo, meter, section markers, and MIDI events.
- Saves the style path and selected section in the Logic project state.
- Plays style sections from the plugin's independent START/STOP control. Main variations loop; Intro plays once and moves to the selected Main; Fill and Break play once and return to Main; Ending plays once and stops.
- Queues a section selection made during playback: after the active Intro/Fill/Break/Ending finishes, or at the next bar boundary for a looping section. The section button grid is populated from the loaded style.
- The plugin's START/STOP toggle controls accompaniment independently of Logic's transport. Its internal clock follows Logic tempo/meter when available and otherwise uses the style's tempo/meter.
- Provides a demonstration bass-and-chord pattern when no style is loaded, controlled by the same plugin START/STOP toggle.
- Uses a Vintage arranger-inspired panel with the loaded style name and section buttons; sections are grouped in arranger order. The style-name card expands for long names, the editor lists each MIDI channel with its readable part and instrument name without PC numbers, and the editor grows taller for large section sets; see [mockup/](mockup/).

## Try it in Logic

Load a style and press START in the plugin. With an Intro selected, it plays once and moves to the current Main variation (or the first Main if none has been selected); with a Main selected, that variation loops. During playback, Main/Intro/Fill/Break/Ending selections are queued to the next bar boundary. Fill and Break return to the last selected Main after one pass; Ending stops the arranger after one pass. START/STOP controls only the arranger; it does not start or stop Logic's transport. Logic supplies tempo and meter when available. Logic still has to process the track and route the MIDI FX output to an instrument.

## Known limitations

- Imported style notes follow the detected chord root and basic triad quality. A new harmony is applied at an arranger bar boundary; active notes are released using their actual transformed pitches.
- This first chord-follow pass assumes style note data is centered on C major. It transforms notes globally and is a prototype, not Yamaha's per-part CASM/NTR/NTT/RTR behavior.
- Selected Yamaha CASM fields are decoded for inspection, but the parser does not yet apply NTR/NTT/RTR rules to individual style parts. Passing chords, non-chord melody notes, and channel-specific transposition may not match a Yamaha arranger exactly.
- Section role recognition uses marker names; styles with unusual marker names may not classify Intro/Main/Fill/Break/Ending correctly.
- Queued transitions align to the next bar boundary, but exact bar alignment depends on usable style/host meter information. More Yamaha-specific transition and CASM behavior still needs validation with varied styles.
- Style parts are not yet mapped to instrument patches. A MIDI effect cannot directly create Logic tracks or instantiate Logic instruments; instrument routing is a separate design task.
- The channel summary reports CASM part labels and standard MIDI Program Change values when present. Yamaha bank/voice SysEx and model-specific voice names are not decoded, so a missing Program Change is shown as such rather than guessed.
- The style loader/playback and chord timing still need more end-to-end musical verification in Logic. The parser has been smoke-checked against five local user-supplied SFF1/SFF2 files.
- Logic must continue processing the track and route the MIDI output to an instrument. Whether this AU MIDI effect is continuously called while Logic's transport is stopped still needs direct verification in Logic.
- No Yamaha style files are bundled in the repository or build artifacts.

## Build and compatibility

- Current continuous-integration target: Intel x86_64 AU, macOS 10.13 deployment target.
- The Intel AU has built successfully in GitHub Actions. A previous Apple Silicon build also succeeded, but CI is temporarily Intel-only while the current UI and behavior are stabilized.
- The AU is a MIDI effect; place it in Logic's MIDI FX slot before a software instrument.
- See [docs/implementation-status.md](docs/implementation-status.md) for implementation detail and [Smart_Arranger.md](Smart_Arranger.md) for the original product brief.

## Next work

1. Verify the v27 adaptive editor width and height, larger channel labels, aligned header controls, and section/transport layout in Logic with short and long names and small and large styles.
2. Replace the global C-major-reference chord transform with per-part Yamaha CASM/NTR/NTT/RTR behavior; improve passing-chord handling and voice leading.
3. Validate queued section flow in Logic with real styles: Intro once, Main variations, Fill/Break return, and Ending stop.
4. Add optional Sync Start and a separate Sync mode for Logic transport/tempo. Keep arranger START/STOP independent when Sync is off.
5. Map style channels to parts and design a practical Logic instrument-routing workflow for multi-part playback.
6. Improve chord recognition, voicing, note cleanup, state restoration, and compatibility checks on supported Logic/macOS versions.
7. Add an optional on-screen keyboard with chord-zone and melody-zone highlighting.

## Development rules

- Treat user-provided style files as local test fixtures; do not commit them unless redistribution is expressly permitted.
- Do not claim support for a format or host behavior until it is tested with real files in Logic.
