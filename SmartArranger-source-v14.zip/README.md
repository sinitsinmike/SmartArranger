# Smart Arranger

Smart Arranger is planned as a live AU MIDI arranger for Logic Pro. It will play imported style parts while the user performs chords on a MIDI keyboard.

The product requirements and compatibility target are in [Smart_Arranger.md](Smart_Arranger.md). The supplied interface image is a visual reference, not a final design specification.

## Current status

The AU prototype has been built successfully on GitHub Actions for Intel macOS and loaded in Logic Pro on the user's Apple Silicon Mac. The workflow is configured to build separate Intel and native Apple Silicon artifacts. It observes incoming MIDI, displays a preliminary live chord estimate, reads Yamaha style metadata and events, and can host-sync and loop one selected style section unchanged. With no style loaded, its optional accompaniment switch falls back to a simple bass-and-chord pattern that follows the host time signature and tempo. The accompaniment switch, selected style path, and selected section are saved with the host project; the editor restores the style from the same local path when reopened.

The editor now uses an arranger-style dark panel with the loaded style at the top, dynamically generated section buttons, and a live chord display. Selecting a section button switches the looped section; the accompaniment switch starts or stops playback. This remains an early prototype: chord recognition uses pitch classes and playback does not yet adapt notes through Yamaha CASM/NTR/NTT rules or sequence transitions between sections. Style files are user-supplied and are not bundled in the repository; keep them local unless the applicable license expressly allows redistribution. The repository workflow retains downloadable build artifacts.

See [docs/environment-assessment.md](docs/environment-assessment.md) and [docs/compatibility-research.md](docs/compatibility-research.md) for observed setup, source findings, and remaining host checks.

## Compatibility targets

- Required: Intel x86_64, macOS High Sierra 10.13, Logic Pro 10.4.4
- Additional: Apple Silicon Logic Pro; currently loaded successfully on the user's Mac, but the active architecture/Rosetta mode has not been determined
- Framework: JUCE 9.0.4

## Project rule

Do not claim support for a style format, AU MIDI routing behavior, or target OS until it has been verified with real files and on the target setup. Keep the live chord detector clearly labeled as preliminary until validated against musical test cases.
