#pragma once

#include <JuceHeader.h>
#include <array>
#include <atomic>
#include <cstdint>
#include <vector>
#include "StyleFile.h"

class SmartArrangerAudioProcessor final : public juce::AudioProcessor
{
public:
    SmartArrangerAudioProcessor();

    void prepareToPlay (double sampleRate, int maximumExpectedSamplesPerBlock) override;
    void releaseResources() override;
    void processBlock (juce::AudioBuffer<float>& audio, juce::MidiBuffer& midi) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override;

    const juce::String getName() const override;
    bool acceptsMidi() const override;
    bool producesMidi() const override;
    bool isMidiEffect() const override;
    double getTailLengthSeconds() const override;

    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram (int index) override;
    const juce::String getProgramName (int index) override;
    void changeProgramName (int index, const juce::String& newName) override;

    void getStateInformation (juce::MemoryBlock& destination) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    int getDetectedChordRoot() const noexcept;
    int getDetectedChordQuality() const noexcept;
    void setAccompanimentEnabled (bool shouldEnable) noexcept;
    bool isAccompanimentEnabled() const noexcept;
    bool setLoadedStyle (const SmartArrangerStyleInfo& style, int sectionIndex,
                        juce::String& error, const juce::File& sourceFile);
    juce::String getStoredStylePath() const;
    int getStoredStyleSection() const noexcept;
    void clearLoadedStyle (bool clearSavedSelection = true) noexcept;
    juce::AudioProcessorValueTreeState& getParameterState() noexcept;

    enum ChordQuality
    {
        noChord = 0,
        major,
        minor,
        diminished,
        augmented,
        suspendedSecond,
        suspendedFourth,
        dominantSeventh,
        majorSeventh,
        minorSeventh,
        halfDiminishedSeventh,
        diminishedSeventh
    };

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    void updateDetectedChord() noexcept;
    void renderAccompaniment (juce::MidiBuffer& midi, int blockSamples) noexcept;
    bool renderLoadedStyle (juce::MidiBuffer& midi, int blockSamples) noexcept;

    struct StylePlaybackData
    {
        std::vector<SmartArrangerStyleEvent> events;
        uint64_t sectionLengthTicks = 0;
        int ticksPerQuarter = 0;
        int tempo = 120;
        int numerator = 4;
        int denominator = 4;
    };

    // MIDI events are consumed and updated on the audio thread. The editor
    // reads only the atomics, so no UI lock is taken by processBlock().
    std::array<uint8_t, 16 * 128> heldNotes {};
    std::atomic<int> detectedChordRoot { -1 };
    std::atomic<int> detectedChordQuality { noChord };
    juce::AudioProcessorValueTreeState parameters;
    std::atomic<float>* accompanimentEnabledParameter = nullptr;
    std::array<uint8_t, 5> activeGeneratedNotes { 255, 255, 255, 255, 255 };
    int64_t lastGeneratedStep = -1;
    std::array<StylePlaybackData, 2> stylePlaybackBuffers;
    std::array<std::atomic<int>, 2> styleReaders { 0, 0 };
    std::atomic<int> activeStyleBuffer { -1 };
    std::array<uint8_t, 16 * 128> activeStyleNotes {};
    std::array<uint8_t, 16 * 128> activeStyleOutputNotes {};
    int64_t styleHarmonyBar = -1;
    int styleHarmonyRoot = 0;
    int styleHarmonyQuality = major;
    double lastStyleBlockEndPpq = 0.0;
    double styleClockPpq = 0.0;
    double fallbackClockPpq = 0.0;
    bool styleWasPlaying = false;
    int styleBufferInUse = -1;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (SmartArrangerAudioProcessor)
};
