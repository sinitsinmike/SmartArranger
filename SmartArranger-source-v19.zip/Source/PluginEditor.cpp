#include "PluginEditor.h"

namespace
{
const juce::Colour background (0xff0b1118);
const juce::Colour panel (0xff171d23);
const juce::Colour panelEdge (0xff665238);
const juce::Colour muted (0xffb8aa91);
const juce::Colour cyan (0xff67b8d5);
const juce::Colour gold (0xffe9b85b);

juce::String getChordLabel (int root, int quality)
{
    if (root < 0 || root > 11)
        return "N/C";

    static const char* noteNames[] = { "C", "C#", "D", "D#", "E", "F",
                                       "F#", "G", "G#", "A", "A#", "B" };
    static const char* suffixes[] = { "", "", "m", "dim", "aug", "sus2", "sus4",
                                      "7", "maj7", "m7", "m7b5", "dim7" };
    if (quality < 0 || quality >= 12)
        return "N/C";
    return juce::String (noteNames[root]) + suffixes[quality];
}

void styleButton (juce::TextButton& button, juce::Colour colour)
{
    button.setColour (juce::TextButton::buttonColourId, panel.brighter (0.12f));
    button.setColour (juce::TextButton::buttonOnColourId, colour.withAlpha (0.98f));
    button.setColour (juce::TextButton::textColourOffId, juce::Colour (0xffeee7d8));
    button.setColour (juce::TextButton::textColourOnId, juce::Colour (0xff21180c));
    button.setClickingTogglesState (true);
}
}

SmartArrangerAudioProcessorEditor::SmartArrangerAudioProcessorEditor (
    SmartArrangerAudioProcessor& processorToUse)
    : juce::AudioProcessorEditor (processorToUse), targetProcessor (processorToUse)
{
    setSize (760, 510);
    addAndMakeVisible (loadStyleButton);
    loadStyleButton.onClick = [this] { chooseStyleFile(); };
    loadStyleButton.setColour (juce::TextButton::buttonColourId, juce::Colour (0xff34291c));
    loadStyleButton.setColour (juce::TextButton::textColourOffId, juce::Colour (0xffffe6b2));

    addAndMakeVisible (accompanimentButton);
    accompanimentButton.setClickingTogglesState (true);
    accompanimentButton.setColour (juce::TextButton::buttonColourId, panel.brighter (0.12f));
    accompanimentButton.setColour (juce::TextButton::buttonOnColourId, juce::Colour (0xffe9b85b));
    accompanimentButton.setColour (juce::TextButton::textColourOffId, juce::Colour (0xffeee7d8));
    accompanimentButton.setColour (juce::TextButton::textColourOnId, juce::Colour (0xff21180c));
    accompanimentAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (
        targetProcessor.getParameterState(), "accompanimentEnabled", accompanimentButton);
    startTimerHz (20);
}

void SmartArrangerAudioProcessorEditor::resized()
{
    auto area = getLocalBounds().reduced (22);
    auto header = area.removeFromTop (54);
    loadStyleButton.setBounds (header.removeFromRight (174).reduced (0, 6));
    area.removeFromTop (80);
    area.removeFromTop (18);
    auto sections = area.removeFromTop (218);
    sections.removeFromTop (34);
    accompanimentButton.setBounds (getWidth() - 220, 178, 178, 30);
    const int columns = 4;
    const int gap = 9;
    const int rows = juce::jmax (1, (sectionButtons.size() + columns - 1) / columns);
    const int buttonHeight = juce::jmin (44, (sections.getHeight() - gap * (rows - 1)) / rows);
    for (int i = 0; i < sectionButtons.size(); ++i)
    {
        const int row = i / columns;
        const int column = i % columns;
        const int width = (sections.getWidth() - gap * (columns - 1)) / columns;
        sectionButtons[i]->setBounds (sections.getX() + column * (width + gap),
                                      sections.getY() + row * (buttonHeight + gap),
                                      width, buttonHeight);
    }
}

void SmartArrangerAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (background);
    auto bounds = getLocalBounds().reduced (12);
    g.setGradientFill (juce::ColourGradient (juce::Colour (0xff1a2026), 0.0f, 0.0f,
                                             juce::Colour (0xff0c1218), 0.0f,
                                             (float) getHeight(), false));
    g.fillRoundedRectangle (bounds.toFloat(), 16.0f);
    g.setColour (panelEdge);
    g.drawRoundedRectangle (bounds.toFloat(), 16.0f, 1.5f);
    g.setColour (gold.withAlpha (0.18f));
    g.drawRoundedRectangle (bounds.reduced (4).toFloat(), 13.0f, 0.7f);

    g.setColour (juce::Colour (0xffedf5fb));
    g.setFont (juce::Font (25.0f, juce::Font::bold));
    g.drawText ("SMART", 28, 17, 102, 34, juce::Justification::centredLeft);
    g.setColour (gold);
    g.drawText ("ARRANGER", 128, 17, 175, 34, juce::Justification::centredLeft);
    const juce::Rectangle<float> titleCard (310.0f, 12.0f, 238.0f, 48.0f);
    g.setColour (juce::Colour (0xff211c15));
    g.fillRoundedRectangle (titleCard, 9.0f);
    g.setColour (gold.withAlpha (0.60f));
    g.drawRoundedRectangle (titleCard, 9.0f, 1.0f);
    g.setColour (muted);
    g.setFont (juce::Font (9.0f, juce::Font::bold));
    g.drawText ("STYLE", 323, 15, 210, 12, juce::Justification::centredLeft);
    g.setColour (juce::Colour (0xffedf5fb));
    g.setFont (juce::Font (13.0f, juce::Font::bold));
    g.drawFittedText (styleTitle, 323, 28, 210, 21,
                      juce::Justification::centredLeft, 1);

    auto styleCard = juce::Rectangle<int> (26, 76, getWidth() - 52, 80);
    g.setGradientFill (juce::ColourGradient (juce::Colour (0xff242a30), 26.0f, 76.0f,
                                             juce::Colour (0xff11171d), 26.0f,
                                             156.0f, false));
    g.fillRoundedRectangle (styleCard.toFloat(), 12.0f);
    g.setColour (gold.withAlpha (0.48f));
    g.drawRoundedRectangle (styleCard.toFloat(), 12.0f, 1.2f);
    g.setColour (juce::Colour (0xfff2f7fb));
    g.setFont (juce::Font (19.0f, juce::Font::bold));
    g.drawText (styleSummary, 42, 86, getWidth() - 250, 30,
                juce::Justification::centredLeft, true);
    g.setColour (styleError.isEmpty() ? muted : juce::Colour (0xffff8c83));
    g.setFont (juce::Font (12.0f));
    g.drawText (styleError.isNotEmpty() ? styleError : styleDetails,
                42, 119, getWidth() - 84, 25, juce::Justification::centredLeft, true);

    g.setColour (juce::Colour (0xff151b21));
    g.fillRoundedRectangle (26.0f, 174.0f, (float) getWidth() - 52.0f, 225.0f, 12.0f);
    g.setColour (gold.withAlpha (0.40f));
    g.drawRoundedRectangle (26.0f, 174.0f, (float) getWidth() - 52.0f, 225.0f, 12.0f, 1.2f);
    g.setColour (gold);
    g.setFont (juce::Font (12.0f, juce::Font::bold));
    g.drawText ("STYLE SECTIONS", 42, 184, 200, 22, juce::Justification::centredLeft);
    if (sectionButtons.isEmpty())
    {
        g.setColour (muted);
        g.setFont (juce::Font (15.0f));
        g.drawFittedText ("LOAD A STYLE FILE TO SHOW INTRO, MAIN, FILL AND ENDING SECTIONS",
                          42, 235, getWidth() - 84, 42, juce::Justification::centred, 1);
    }

    const int chordTop = 420;
    g.setColour (juce::Colour (0xff151b21));
    g.fillRoundedRectangle (26.0f, (float) chordTop, (float) getWidth() - 52.0f, 64.0f, 12.0f);
    g.setColour (gold.withAlpha (0.43f));
    g.drawRoundedRectangle (26.0f, (float) chordTop, (float) getWidth() - 52.0f, 64.0f, 12.0f, 1.1f);
    g.setColour (gold);
    g.setFont (juce::Font (11.0f, juce::Font::bold));
    g.drawText ("LIVE CHORD", 42, chordTop + 8, 100, 18, juce::Justification::centredLeft);
    g.setColour (juce::Colour (0xfff1f6fa));
    g.setFont (juce::Font (27.0f, juce::Font::bold));
    g.drawText (getChordLabel (targetProcessor.getDetectedChordRoot(),
                               targetProcessor.getDetectedChordQuality()),
                42, chordTop + 24, 105, 32, juce::Justification::centredLeft);
    g.setColour (muted);
    g.setFont (juce::Font (12.0f));
    g.drawFittedText ("Play a chord in Logic. The latest recognized harmony stays active.",
                      160, chordTop + 18, getWidth() - 206, 32,
                      juce::Justification::centredLeft, 1);
}

void SmartArrangerAudioProcessorEditor::chooseStyleFile()
{
    fileChooser = std::make_unique<juce::FileChooser> ("Choose a Yamaha Style file",
        juce::File(), "*.sty;*.STY;*.prs;*.PRS;*.bcs;*.BCS;*.sst;*.SST;*.scp;*.SCP;*.fps;*.FPS;*.aus;*.AUS");
    juce::Component::SafePointer<SmartArrangerAudioProcessorEditor> safeThis (this);
    fileChooser->launchAsync (juce::FileBrowserComponent::openMode
                                  | juce::FileBrowserComponent::canSelectFiles,
                              [safeThis] (const juce::FileChooser& chooser)
                              {
                                  if (safeThis != nullptr && chooser.getResult().existsAsFile())
                                      safeThis->loadStyleFile (chooser.getResult());
                              });
}

void SmartArrangerAudioProcessorEditor::loadStyleFile (const juce::File& file)
{
    lastRestoreAttemptPath = file.getFullPathName();
    SmartArrangerStyleInfo info;
    juce::String error;
    if (! SmartArrangerStyleFile::inspect (file, info, error))
    {
        const bool retryingSavedStyle = file.getFullPathName() == targetProcessor.getStoredStylePath();
        if (! retryingSavedStyle)
            targetProcessor.clearLoadedStyle();
        loadedStyleInfo = {};
        sectionButtons.clear (true);
        styleTitle = "STYLE NOT LOADED";
        styleSummary = "Could not load " + file.getFileName();
        styleDetails.clear();
        styleError = error;
        resized(); repaint();
        return;
    }

    loadedStyleInfo = std::move (info);
    loadedStylePath = file.getFullPathName();
    const bool restoringSameStyle = loadedStylePath == targetProcessor.getStoredStylePath();
    const int sectionToLoad = restoringSameStyle
        ? juce::jlimit (0, (int) loadedStyleInfo.sections.size() - 1,
                        targetProcessor.getStoredStyleSection()) : 0;
    rebuildSectionButtons (sectionToLoad);
    if (! targetProcessor.setLoadedStyle (loadedStyleInfo, sectionToLoad, error, file))
    {
        targetProcessor.clearLoadedStyle();
        styleTitle = loadedStyleInfo.name;
        styleSummary = "Style parsed";
        styleDetails.clear();
        styleError = error;
        resized(); repaint();
        return;
    }

    int channels = 0;
    for (int channel = 0; channel < 16; ++channel)
        if ((loadedStyleInfo.usedChannels & (1u << channel)) != 0) ++channels;
    styleTitle = loadedStyleInfo.name;
    styleSummary = loadedStyleInfo.format + " | "
                 + juce::String (loadedStyleInfo.tempo) + " BPM | "
                 + juce::String (loadedStyleInfo.numerator) + "/" + juce::String (loadedStyleInfo.denominator);
    styleDetails = juce::String ((int) loadedStyleInfo.sections.size()) + " sections | "
                 + juce::String (channels) + " MIDI channels | "
                 + juce::String ((int) loadedStyleInfo.events.size()) + " events";
    styleError.clear();
    resized(); repaint();
}

void SmartArrangerAudioProcessorEditor::rebuildSectionButtons (int selectedIndex)
{
    sectionButtons.clear (true);
    for (int i = 0; i < (int) loadedStyleInfo.sections.size(); ++i)
    {
        const auto name = loadedStyleInfo.sections[(size_t) i].name;
        auto* button = sectionButtons.add (new juce::TextButton (name));
        const auto folded = name.toLowerCase();
        const auto accent = folded.contains ("intro") ? cyan
                          : (folded.contains ("main") ? gold
                          : (folded.contains ("fill") ? juce::Colour (0xff529aff)
                          : (folded.contains ("break") ? juce::Colour (0xffc27bff)
                          : (folded.contains ("end") ? juce::Colour (0xffff776e) : cyan))));
        styleButton (*button, accent);
        button->setRadioGroupId (7001);
        button->setToggleState (i == selectedIndex, juce::dontSendNotification);
        button->onClick = [this, i] { selectStyleSection (i); };
        addAndMakeVisible (button);
    }
    resized();
}

void SmartArrangerAudioProcessorEditor::selectStyleSection (int index)
{
    if (index < 0 || index >= (int) loadedStyleInfo.sections.size()) return;
    juce::String error;
    if (! targetProcessor.setLoadedStyle (loadedStyleInfo, index, error, juce::File (loadedStylePath)))
    {
        styleError = error;
        repaint();
    }
    else
    {
        styleError.clear();
        repaint();
    }
}

void SmartArrangerAudioProcessorEditor::activateStyleSection()
{
    selectStyleSection (0);
}

void SmartArrangerAudioProcessorEditor::timerCallback()
{
    accompanimentButton.setButtonText (accompanimentButton.getToggleState()
        ? "■  STOP" : "▶  START");
    const auto storedPath = targetProcessor.getStoredStylePath();
    if (storedPath.isNotEmpty() && storedPath != loadedStylePath
        && storedPath != lastRestoreAttemptPath)
    {
        loadStyleFile (juce::File (storedPath));
        return;
    }
    repaint();
}
