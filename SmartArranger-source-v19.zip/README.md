# Smart Arranger

Smart Arranger is an experimental AU MIDI effect for Logic Pro. It is being developed as a style-based live arranger: play chords on a MIDI keyboard and have accompaniment follow them.

## Implemented

- AU MIDI effect target for Logic Pro, built with JUCE 9.0.4.
- Passes incoming MIDI through and shows a preliminary live chord estimate.
- Loads a user-selected Yamaha-style file from disk and reads its title, tempo, meter, section markers, and MIDI events.
- Saves the style path and selected section in the Logic project state.
- Plays and loops one selected style section from the plugin's independent START/STOP control. The section button grid is populated from the loaded style.
- The plugin's START/STOP toggle controls accompaniment independently of Logic's transport. Its internal clock follows Logic tempo/meter when available and otherwise uses the style's tempo/meter.
- Provides a demonstration bass-and-chord pattern when no style is loaded, controlled by the same plugin START/STOP toggle.
- Uses a Vintage arranger-inspired panel with the loaded style name and section buttons; see [mockup/](mockup/).

## Try it in Logic

Load a style, choose a section, and press START in the plugin. START/STOP controls only the arranger; it does not start or stop Logic's transport. The selected section repeats until STOP or another section is selected. Logic still hosts the audio/MIDI processing and supplies tempo/meter when available. Selecting an Intro currently repeats it; automatic Intro-to-Main flow is planned.

## Known limitations

- Imported style notes follow the detected chord root and basic triad quality. A new harmony is applied at an arranger bar boundary; active notes are released using their actual transformed pitches.
- This first chord-follow pass assumes style note data is centered on C major. It transforms notes globally and is a prototype, not Yamaha's per-part CASM/NTR/NTT/RTR behavior.
- Yamaha CASM, NTR, NTT, and RTR rules are not yet interpreted, so passing chords, non-chord melody notes, and channel-specific transposition may not match a Yamaha arranger exactly.
- Section buttons select a loop directly; queued transitions, automatic fills, intro-to-main flow, breaks, and endings are not sequenced yet.
- Style parts are not yet mapped to instrument patches. A MIDI effect cannot directly create Logic tracks or instantiate Logic instruments; instrument routing is a separate design task.
- The style loader/playback and chord timing still need more end-to-end musical verification in Logic. The parser has been smoke-checked against five local user-supplied SFF1/SFF2 files.
- Logic must continue processing the track and route the MIDI output to an instrument. Whether this AU MIDI effect is continuously called while Logic's transport is stopped still needs direct verification in Logic.
- No Yamaha style files are bundled in the repository or build artifacts.

## Build and compatibility

- Current continuous-integration target: Intel x86_64 AU, macOS 10.13 deployment target.
- The Intel AU has built successfully in GitHub Actions. A previous Apple Silicon build also succeeded, but CI is temporarily Intel-only while the current UI and behavior are stabilized.
- The AU is a MIDI effect; place it in Logic's MIDI FX slot before a software instrument.
- See [docs/implementation-status.md](docs/implementation-status.md) for implementation detail and [Smart_Arranger.md](Smart_Arranger.md) for the original product brief.

## Next work

1. Verify the latest Intel AU's text rendering, style loading, section buttons, and playback in Logic.
2. Polish the editor layout: section buttons protrude slightly beyond the section panel's left and right edges, and the accompaniment button sits too close to the first row. Rework the horizontal margins and vertical spacing in a dedicated UI pass.
3. Replace the global C-major-reference chord transform with per-part Yamaha CASM/NTR/NTT/RTR behavior; improve passing-chord handling and voice leading.
4. Add musical section transitions: Intro, Main A-D, Fill, Break, and Ending with bar-aware switching.
5. Add queued section flow: Intro once, then selected Main; queue fills/breaks and end cleanly. Keep arranger START/STOP separate from Logic transport.
6. Map style channels to parts and design a practical Logic instrument-routing workflow for multi-part playback.
7. Improve chord recognition, voicing, note cleanup, state restoration, and compatibility checks on supported Logic/macOS versions.
8. Add an optional on-screen keyboard with chord-zone and melody-zone highlighting.

## Development rules

- Treat user-provided style files as local test fixtures; do not commit them unless redistribution is expressly permitted.
- Do not claim support for a format or host behavior until it is tested with real files in Logic.
