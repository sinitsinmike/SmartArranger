#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"

class SmartArrangerAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                                private juce::Timer
{
public:
    explicit SmartArrangerAudioProcessorEditor (SmartArrangerAudioProcessor& processor);
    void paint (juce::Graphics& graphics) override;
    void timerCallback() override;

private:
    SmartArrangerAudioProcessor& processor;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (SmartArrangerAudioProcessorEditor)
};
