#include "PluginEditor.h"

namespace
{
juce::String getChordLabel (int root, int quality)
{
    if (root < 0 || root > 11)
        return "—";

    static const char* noteNames[] = { "C", "C#", "D", "D#", "E", "F",
                                       "F#", "G", "G#", "A", "A#", "B" };
    static const char* suffixes[] = { "", "", "m", "dim", "aug", "sus2", "sus4",
                                      "7", "maj7", "m7", "m7b5", "dim7" };
    if (quality < 0 || quality >= 12)
        return "—";

    return juce::String (noteNames[root]) + suffixes[quality];
}
}

SmartArrangerAudioProcessorEditor::SmartArrangerAudioProcessorEditor (
    SmartArrangerAudioProcessor& processorToUse)
    : juce::AudioProcessorEditor (processorToUse), processor (processorToUse)
{
    setSize (520, 300);
    startTimerHz (20);
}

void SmartArrangerAudioProcessorEditor::paint (juce::Graphics& graphics)
{
    graphics.fillAll (juce::Colour::fromRGB (16, 22, 30));
    graphics.setColour (juce::Colour::fromRGB (232, 237, 243));
    graphics.setFont (juce::Font (26.0f, juce::Font::bold));
    graphics.drawFittedText ("SMART ARRANGER", getLocalBounds().reduced (24, 28),
                             juce::Justification::centredTop, 1);

    graphics.setColour (juce::Colour::fromRGB (111, 178, 242));
    graphics.setFont (juce::Font (15.0f, juce::Font::bold));
    graphics.drawFittedText ("LIVE CHORD", getLocalBounds().withTrimmedTop (86).removeFromTop (24),
                             juce::Justification::centred, 1);

    graphics.setColour (juce::Colour::fromRGB (245, 247, 250));
    graphics.setFont (juce::Font (42.0f, juce::Font::bold));
    graphics.drawFittedText (getChordLabel (processor.getDetectedChordRoot(),
                                            processor.getDetectedChordQuality()),
                             getLocalBounds().withTrimmedTop (108).removeFromTop (62),
                             juce::Justification::centred, 1);

    graphics.setColour (juce::Colour::fromRGB (168, 185, 199));
    graphics.setFont (juce::Font (15.0f));
    graphics.drawFittedText ("Play three or more notes to detect a chord",
                             getLocalBounds().withTrimmedTop (190).removeFromTop (28),
                             juce::Justification::centred, 1);
    graphics.drawFittedText ("MIDI passes through unchanged",
                             getLocalBounds().withTrimmedTop (238).removeFromTop (24),
                             juce::Justification::centred, 1);
}

void SmartArrangerAudioProcessorEditor::timerCallback()
{
    repaint();
}
