# Implementation status

## Increment 1: live chord display

- Observe Note On/Off events in the incoming MIDI stream without modifying the stream.
- Track held notes by MIDI channel and note number.
- Recognize common major, minor, diminished, augmented, suspended, and seventh-chord pitch-class patterns.
- Display the current estimate in the AU editor.
- Keep the audio callback free of UI locks; the editor polls atomic chord state.

### Current limits

- The detector examines all held notes and can misidentify extensions, melody notes, inversions, or ambiguous pitch collections.
- Chord root/quality detection is not yet wired to an accompaniment engine.
- No `.STY` parser, style playback, section transitions, or multi-part routing is implemented.
- Compilation proves the AU target builds, not that this detector has been musically validated in Logic.

## Next increments

1. Improve chord-zone handling and validate chord labels against played examples.
2. Inspect real user-provided `.STY` files and define the first supported subset.
3. Parse one style and display its actual sections and parts.
4. Add synchronized playback of a single unchanged style section.
5. Add chord adaptation and transitions only after playback timing is reliable.
