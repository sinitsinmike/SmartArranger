# Smart Arranger

Smart Arranger is planned as a live AU MIDI arranger for Logic Pro. It will play imported style parts while the user performs chords on a MIDI keyboard.

The product requirements and compatibility target are in [Smart_Arranger.md](Smart_Arranger.md). The supplied interface image is a visual reference, not a final design specification.

## Current status

The AU prototype has been built successfully on GitHub Actions for Intel macOS and loaded in Logic Pro on the user's Apple Silicon Mac. The first functional increment observes incoming MIDI without changing it and displays a live chord estimate in the plug-in window. It recognizes common triad and seventh-chord qualities.

This is still an early prototype: chord recognition uses pitch classes and does not yet apply Yamaha CASM/NTR/NTT rules or generate accompaniment. The Intel AU is not a native Apple Silicon build. The repository workflow retains downloadable build artifacts.

See [docs/environment-assessment.md](docs/environment-assessment.md) and [docs/compatibility-research.md](docs/compatibility-research.md) for observed setup, source findings, and remaining host checks.

## Compatibility targets

- Required: Intel x86_64, macOS High Sierra 10.13, Logic Pro 10.4.4
- Additional: Apple Silicon Logic Pro; currently loaded successfully on the user's Mac, but the active architecture/Rosetta mode has not been determined
- Framework: JUCE 9.0.4

## Project rule

Do not claim support for a style format, AU MIDI routing behavior, or target OS until it has been verified with real files and on the target setup. Keep the live chord detector clearly labeled as preliminary until validated against musical test cases.
