#include "PluginProcessor.h"
#include "PluginEditor.h"

SmartArrangerAudioProcessor::SmartArrangerAudioProcessor()
    : juce::AudioProcessor (juce::AudioProcessor::BusesProperties())
{
}

void SmartArrangerAudioProcessor::prepareToPlay (double, int)
{
    heldNotes.fill (0);
    detectedChordRoot.store (-1, std::memory_order_relaxed);
    detectedChordQuality.store (noChord, std::memory_order_relaxed);
}

void SmartArrangerAudioProcessor::releaseResources()
{
    heldNotes.fill (0);
    detectedChordRoot.store (-1, std::memory_order_relaxed);
    detectedChordQuality.store (noChord, std::memory_order_relaxed);
}

void SmartArrangerAudioProcessor::processBlock (juce::AudioBuffer<float>& audio,
                                                 juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    audio.clear();

    // Pass MIDI through unchanged while observing held notes for chord
    // recognition. State is maintained per channel and key, including the
    // velocity-zero Note On form of Note Off.
    for (const auto metadata : midi)
    {
        const auto& message = metadata.getMessage();
        if (! message.isNoteOn() && ! message.isNoteOff())
            continue;

        const int note = message.getNoteNumber();
        const int channel = message.getChannel() - 1;
        if (note < 0 || note >= 128 || channel < 0 || channel >= 16)
            continue;

        heldNotes[static_cast<size_t> (channel * 128 + note)] = message.isNoteOn() ? 1 : 0;
        updateDetectedChord();
    }
}

namespace
{
struct ChordPattern
{
    SmartArrangerAudioProcessor::ChordQuality quality;
    uint16_t intervals;
};

constexpr ChordPattern chordPatterns[] =
{
    { SmartArrangerAudioProcessor::major,                 (1u << 0) | (1u << 4) | (1u << 7) },
    { SmartArrangerAudioProcessor::minor,                 (1u << 0) | (1u << 3) | (1u << 7) },
    { SmartArrangerAudioProcessor::diminished,            (1u << 0) | (1u << 3) | (1u << 6) },
    { SmartArrangerAudioProcessor::augmented,             (1u << 0) | (1u << 4) | (1u << 8) },
    { SmartArrangerAudioProcessor::suspendedSecond,       (1u << 0) | (1u << 2) | (1u << 7) },
    { SmartArrangerAudioProcessor::suspendedFourth,       (1u << 0) | (1u << 5) | (1u << 7) },
    { SmartArrangerAudioProcessor::dominantSeventh,       (1u << 0) | (1u << 4) | (1u << 7) | (1u << 10) },
    { SmartArrangerAudioProcessor::majorSeventh,          (1u << 0) | (1u << 4) | (1u << 7) | (1u << 11) },
    { SmartArrangerAudioProcessor::minorSeventh,          (1u << 0) | (1u << 3) | (1u << 7) | (1u << 10) },
    { SmartArrangerAudioProcessor::halfDiminishedSeventh, (1u << 0) | (1u << 3) | (1u << 6) | (1u << 10) },
    { SmartArrangerAudioProcessor::diminishedSeventh,     (1u << 0) | (1u << 3) | (1u << 6) | (1u << 9) }
};

int countBits (uint16_t bits) noexcept
{
    int count = 0;
    while (bits != 0)
    {
        count += bits & 1u;
        bits >>= 1;
    }
    return count;
}
}

void SmartArrangerAudioProcessor::updateDetectedChord() noexcept
{
    uint16_t pitchClasses = 0;
    int lowestNote = 128;
    for (int channel = 0; channel < 16; ++channel)
    {
        for (int note = 0; note < 128; ++note)
        {
            if (heldNotes[static_cast<size_t> (channel * 128 + note)] == 0)
                continue;

            pitchClasses |= static_cast<uint16_t> (1u << (note % 12));
            lowestNote = juce::jmin (lowestNote, note);
        }
    }

    if (countBits (pitchClasses) < 3)
    {
        detectedChordRoot.store (-1, std::memory_order_relaxed);
        detectedChordQuality.store (noChord, std::memory_order_relaxed);
        return;
    }

    int bestScore = 1000;
    int bestRoot = -1;
    ChordQuality bestQuality = noChord;
    const int bassPitchClass = lowestNote % 12;

    for (int root = 0; root < 12; ++root)
    {
        for (const auto& pattern : chordPatterns)
        {
            uint16_t transposed = 0;
            for (int interval = 0; interval < 12; ++interval)
                if ((pattern.intervals & (1u << interval)) != 0)
                    transposed |= static_cast<uint16_t> (1u << ((root + interval) % 12));

            const int missing = countBits (static_cast<uint16_t> (transposed & ~pitchClasses));
            const int extra = countBits (static_cast<uint16_t> (pitchClasses & ~transposed));
            const int matched = countBits (static_cast<uint16_t> (transposed & pitchClasses));
            if (matched < 3)
                continue;

            const int score = missing * 4 + extra * 2 + (root == bassPitchClass ? 0 : 1);
            if (score < bestScore)
            {
                bestScore = score;
                bestRoot = root;
                bestQuality = pattern.quality;
            }
        }
    }

    if (bestScore >= 1000)
    {
        detectedChordRoot.store (-1, std::memory_order_relaxed);
        detectedChordQuality.store (noChord, std::memory_order_relaxed);
        return;
    }

    detectedChordRoot.store (bestRoot, std::memory_order_relaxed);
    detectedChordQuality.store (bestQuality, std::memory_order_relaxed);
}

int SmartArrangerAudioProcessor::getDetectedChordRoot() const noexcept
{
    return detectedChordRoot.load (std::memory_order_relaxed);
}

int SmartArrangerAudioProcessor::getDetectedChordQuality() const noexcept
{
    return detectedChordQuality.load (std::memory_order_relaxed);
}

juce::AudioProcessorEditor* SmartArrangerAudioProcessor::createEditor()
{
    return new SmartArrangerAudioProcessorEditor (*this);
}

bool SmartArrangerAudioProcessor::hasEditor() const { return true; }
const juce::String SmartArrangerAudioProcessor::getName() const { return JucePlugin_Name; }
bool SmartArrangerAudioProcessor::acceptsMidi() const { return true; }
bool SmartArrangerAudioProcessor::producesMidi() const { return true; }
bool SmartArrangerAudioProcessor::isMidiEffect() const { return true; }
double SmartArrangerAudioProcessor::getTailLengthSeconds() const { return 0.0; }

int SmartArrangerAudioProcessor::getNumPrograms() { return 1; }
int SmartArrangerAudioProcessor::getCurrentProgram() { return 0; }
void SmartArrangerAudioProcessor::setCurrentProgram (int) {}
const juce::String SmartArrangerAudioProcessor::getProgramName (int) { return {}; }
void SmartArrangerAudioProcessor::changeProgramName (int, const juce::String&) {}

void SmartArrangerAudioProcessor::getStateInformation (juce::MemoryBlock&) {}
void SmartArrangerAudioProcessor::setStateInformation (const void*, int) {}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new SmartArrangerAudioProcessor();
}
