#pragma once

#include <JuceHeader.h>
#include <cstdint>
#include <vector>

struct SmartArrangerStyleSection
{
    juce::String name;
    uint64_t lengthTicks = 0;
};

struct SmartArrangerStyleInfo
{
    juce::String name;
    juce::String format;
    int tempo = 120;
    int numerator = 4;
    int denominator = 4;
    int ticksPerQuarter = 0;
    uint16_t usedChannels = 0;
    bool hasCasm = false;
    std::vector<SmartArrangerStyleSection> sections;
};

class SmartArrangerStyleFile
{
public:
    static bool inspect (const juce::File& file,
                         SmartArrangerStyleInfo& result,
                         juce::String& error);
};
