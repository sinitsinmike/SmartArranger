# Implementation status

## Increment 1: live chord display

- Observe Note On/Off events in the incoming MIDI stream without modifying the stream.
- Track held notes by MIDI channel and note number.
- Recognize common major, minor, diminished, augmented, suspended, and seventh-chord pitch-class patterns.
- Display the current estimate in the AU editor.
- Keep the audio callback free of UI locks; the editor polls atomic chord state.

### Current limits

- The detector examines all held notes and can misidentify extensions, melody notes, inversions, or ambiguous pitch collections.
- Chord root/quality detection is not yet wired to an accompaniment engine.
- No `.STY` parser, style playback, section transitions, or multi-part routing is implemented.
- Compilation proves the AU target builds, not that this detector has been musically validated in Logic.

## Increment 2: style metadata inspection

- Add a file picker for `.STY` files.
- Parse the leading MIDI header and one format-0 MIDI track using bounded readers.
- Read tempo, meter, section markers, MIDI channels containing notes, and whether a CASM block exists.
- Skip length-prefixed non-MIDI sections without attempting to interpret their rules.

### Current limits

- The parser has not yet been checked against an actual user `.STY` file, so its supported subset is provisional.
- It does not load or schedule style notes, interpret CASM/NTR/NTT/RTR, or change MIDI output.
- Displayed MIDI channel count is only an observed channel count; it is not a Yamaha part-name mapping.

## Next increments

1. Validate the metadata reader with real SFF1/SFF2 `.STY` files and harden it against variants.
2. Preserve parsed MIDI events and map channels/sections to actual style parts.
3. Add synchronized playback of one unchanged style section.
4. Add chord adaptation from the style's CASM rules.
5. Add section transitions only after playback timing is reliable.
