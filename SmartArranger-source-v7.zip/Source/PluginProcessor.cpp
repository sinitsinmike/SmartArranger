#include "PluginProcessor.h"
#include "PluginEditor.h"

SmartArrangerAudioProcessor::SmartArrangerAudioProcessor()
    : juce::AudioProcessor (juce::AudioProcessor::BusesProperties()),
      parameters (*this, nullptr, "SMART_ARRANGER_STATE", createParameterLayout())
{
    accompanimentEnabledParameter = parameters.getRawParameterValue ("accompanimentEnabled");
}

juce::AudioProcessorValueTreeState::ParameterLayout
SmartArrangerAudioProcessor::createParameterLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;
    layout.add (std::make_unique<juce::AudioParameterBool> (
        juce::ParameterID { "accompanimentEnabled", 1 }, "Accompaniment", false));
    return layout;
}

void SmartArrangerAudioProcessor::prepareToPlay (double, int)
{
    heldNotes.fill (0);
    activeGeneratedNotes.fill (255);
    lastGeneratedEighth = -1;
    detectedChordRoot.store (-1, std::memory_order_relaxed);
    detectedChordQuality.store (noChord, std::memory_order_relaxed);
}

void SmartArrangerAudioProcessor::releaseResources()
{
    heldNotes.fill (0);
    activeGeneratedNotes.fill (255);
    lastGeneratedEighth = -1;
    detectedChordRoot.store (-1, std::memory_order_relaxed);
    detectedChordQuality.store (noChord, std::memory_order_relaxed);
}

void SmartArrangerAudioProcessor::processBlock (juce::AudioBuffer<float>& audio,
                                                 juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    audio.clear();

    // Pass MIDI through unchanged while observing held notes for chord
    // recognition. State is maintained per channel and key, including the
    // velocity-zero Note On form of Note Off.
    for (const auto metadata : midi)
    {
        const auto& message = metadata.getMessage();
        if (! message.isNoteOn() && ! message.isNoteOff())
            continue;

        const int note = message.getNoteNumber();
        const int channel = message.getChannel() - 1;
        if (note < 0 || note >= 128 || channel < 0 || channel >= 16)
            continue;

        heldNotes[static_cast<size_t> (channel * 128 + note)] = message.isNoteOn() ? 1 : 0;
        updateDetectedChord();
    }

    renderAccompaniment (midi, audio.getNumSamples());
}

namespace
{
struct ChordPattern
{
    SmartArrangerAudioProcessor::ChordQuality quality;
    uint16_t intervals;
};

constexpr ChordPattern chordPatterns[] =
{
    { SmartArrangerAudioProcessor::major,                 (1u << 0) | (1u << 4) | (1u << 7) },
    { SmartArrangerAudioProcessor::minor,                 (1u << 0) | (1u << 3) | (1u << 7) },
    { SmartArrangerAudioProcessor::diminished,            (1u << 0) | (1u << 3) | (1u << 6) },
    { SmartArrangerAudioProcessor::augmented,             (1u << 0) | (1u << 4) | (1u << 8) },
    { SmartArrangerAudioProcessor::suspendedSecond,       (1u << 0) | (1u << 2) | (1u << 7) },
    { SmartArrangerAudioProcessor::suspendedFourth,       (1u << 0) | (1u << 5) | (1u << 7) },
    { SmartArrangerAudioProcessor::dominantSeventh,       (1u << 0) | (1u << 4) | (1u << 7) | (1u << 10) },
    { SmartArrangerAudioProcessor::majorSeventh,          (1u << 0) | (1u << 4) | (1u << 7) | (1u << 11) },
    { SmartArrangerAudioProcessor::minorSeventh,          (1u << 0) | (1u << 3) | (1u << 7) | (1u << 10) },
    { SmartArrangerAudioProcessor::halfDiminishedSeventh, (1u << 0) | (1u << 3) | (1u << 6) | (1u << 10) },
    { SmartArrangerAudioProcessor::diminishedSeventh,     (1u << 0) | (1u << 3) | (1u << 6) | (1u << 9) }
};

int countBits (uint16_t bits) noexcept
{
    int count = 0;
    while (bits != 0)
    {
        count += bits & 1u;
        bits >>= 1;
    }
    return count;
}
}

void SmartArrangerAudioProcessor::updateDetectedChord() noexcept
{
    uint16_t pitchClasses = 0;
    int lowestNote = 128;
    for (int channel = 0; channel < 16; ++channel)
    {
        for (int note = 0; note < 128; ++note)
        {
            if (heldNotes[static_cast<size_t> (channel * 128 + note)] == 0)
                continue;

            pitchClasses |= static_cast<uint16_t> (1u << (note % 12));
            lowestNote = juce::jmin (lowestNote, note);
        }
    }

    if (countBits (pitchClasses) < 3)
    {
        // Hold the latest recognized chord after its input notes are released.
        // This is how a style arranger sustains the harmony between changes.
        return;
    }

    int bestScore = 1000;
    int bestRoot = -1;
    ChordQuality bestQuality = noChord;
    const int bassPitchClass = lowestNote % 12;

    for (int root = 0; root < 12; ++root)
    {
        for (const auto& pattern : chordPatterns)
        {
            uint16_t transposed = 0;
            for (int interval = 0; interval < 12; ++interval)
                if ((pattern.intervals & (1u << interval)) != 0)
                    transposed |= static_cast<uint16_t> (1u << ((root + interval) % 12));

            const int missing = countBits (static_cast<uint16_t> (transposed & ~pitchClasses));
            const int extra = countBits (static_cast<uint16_t> (pitchClasses & ~transposed));
            const int matched = countBits (static_cast<uint16_t> (transposed & pitchClasses));
            if (matched < 3)
                continue;

            const int score = missing * 4 + extra * 2 + (root == bassPitchClass ? 0 : 1);
            if (score < bestScore)
            {
                bestScore = score;
                bestRoot = root;
                bestQuality = pattern.quality;
            }
        }
    }

    if (bestScore >= 1000)
    {
        detectedChordRoot.store (-1, std::memory_order_relaxed);
        detectedChordQuality.store (noChord, std::memory_order_relaxed);
        return;
    }

    detectedChordRoot.store (bestRoot, std::memory_order_relaxed);
    detectedChordQuality.store (bestQuality, std::memory_order_relaxed);
}

void SmartArrangerAudioProcessor::renderAccompaniment (juce::MidiBuffer& midi,
                                                        int blockSamples) noexcept
{
    const auto sendNoteOffs = [&] (int samplePosition)
    {
        for (auto& note : activeGeneratedNotes)
        {
            if (note != 255)
            {
                midi.addEvent (juce::MidiMessage::noteOff (1, note), samplePosition);
                note = 255;
            }
        }
    };

    if (! isAccompanimentEnabled() || blockSamples <= 0)
    {
        sendNoteOffs (0);
        lastGeneratedEighth = -1;
        return;
    }

    auto* playHead = getPlayHead();
    if (playHead == nullptr)
    {
        sendNoteOffs (0);
        lastGeneratedEighth = -1;
        return;
    }

    const auto position = playHead->getPosition();
    if (! position.hasValue() || ! position->getIsPlaying())
    {
        sendNoteOffs (0);
        lastGeneratedEighth = -1;
        return;
    }

    const auto ppqPosition = position->getPpqPosition();
    const auto bpmValue = position->getBpm();
    if (! ppqPosition.hasValue() || ! bpmValue.hasValue() || *bpmValue <= 0.0
        || getSampleRate() <= 0.0)
    {
        sendNoteOffs (0);
        lastGeneratedEighth = -1;
        return;
    }

    const double ppqStart = *ppqPosition;
    const double ppqPerBlock = static_cast<double> (blockSamples) * *bpmValue
                             / (60.0 * getSampleRate());
    const auto firstEighth = static_cast<int64_t> (std::ceil (ppqStart * 2.0 - 1.0e-9));
    const auto lastEighth = static_cast<int64_t> (std::floor ((ppqStart + ppqPerBlock) * 2.0 - 1.0e-9));

    if (firstEighth < lastGeneratedEighth)
    {
        sendNoteOffs (0);
        lastGeneratedEighth = firstEighth - 1;
    }

    const int root = detectedChordRoot.load (std::memory_order_relaxed);
    const int quality = detectedChordQuality.load (std::memory_order_relaxed);
    if (root < 0 || root > 11)
    {
        sendNoteOffs (0);
        lastGeneratedEighth = lastEighth;
        return;
    }

    int third = 4;
    int fifth = 7;
    switch (quality)
    {
        case minor: case minorSeventh: case halfDiminishedSeventh: case diminishedSeventh:
            third = 3; break;
        case augmented: fifth = 8; break;
        case suspendedSecond: third = 2; break;
        case suspendedFourth: third = 5; break;
        default: break;
    }
    if (quality == diminished || quality == halfDiminishedSeventh || quality == diminishedSeventh)
        fifth = 6;

    int seventh = -1;
    if (quality == dominantSeventh || quality == minorSeventh || quality == halfDiminishedSeventh)
        seventh = 10;
    else if (quality == majorSeventh)
        seventh = 11;
    else if (quality == diminishedSeventh)
        seventh = 9;

    for (auto eighth = juce::jmax (firstEighth, lastGeneratedEighth + 1);
         eighth <= lastEighth; ++eighth)
    {
        const double eventPpq = static_cast<double> (eighth) * 0.5;
        const int samplePosition = juce::jlimit (0, blockSamples - 1,
            static_cast<int> (std::llround ((eventPpq - ppqStart) * 60.0 * getSampleRate() / *bpmValue)));
        sendNoteOffs (samplePosition);

        const int beatInBar = static_cast<int> (eighth % 8);
        const auto addGenerated = [&] (int note, int velocity)
        {
            note = juce::jlimit (0, 127, note);
            midi.addEvent (juce::MidiMessage::noteOn (1, note, static_cast<juce::uint8> (velocity)),
                           samplePosition);
            for (auto& active : activeGeneratedNotes)
                if (active == 255)
                {
                    active = static_cast<uint8_t> (note);
                    break;
                }
        };

        // A simple first rhythm: bass on beats 1 and 3, chord stabs on 2 and 4.
        // Events are clocked to Logic's PPQ position, so tempo changes follow the host.
        if (beatInBar == 0 || beatInBar == 4)
            addGenerated (36 + root, 92);

        if (beatInBar == 2 || beatInBar == 6)
        {
            addGenerated (60 + root, 78);
            addGenerated (60 + ((root + third) % 12), 74);
            addGenerated (60 + ((root + fifth) % 12), 74);
            if (seventh >= 0)
                addGenerated (60 + ((root + seventh) % 12), 68);
        }

        lastGeneratedEighth = eighth;
    }
}

int SmartArrangerAudioProcessor::getDetectedChordRoot() const noexcept
{
    return detectedChordRoot.load (std::memory_order_relaxed);
}

int SmartArrangerAudioProcessor::getDetectedChordQuality() const noexcept
{
    return detectedChordQuality.load (std::memory_order_relaxed);
}

void SmartArrangerAudioProcessor::setAccompanimentEnabled (bool shouldEnable) noexcept
{
    if (auto* parameter = parameters.getParameter ("accompanimentEnabled"))
        parameter->setValueNotifyingHost (shouldEnable ? 1.0f : 0.0f);
}

bool SmartArrangerAudioProcessor::isAccompanimentEnabled() const noexcept
{
    return accompanimentEnabledParameter != nullptr
        && accompanimentEnabledParameter->load (std::memory_order_relaxed) >= 0.5f;
}

juce::AudioProcessorValueTreeState& SmartArrangerAudioProcessor::getParameterState() noexcept
{
    return parameters;
}

juce::AudioProcessorEditor* SmartArrangerAudioProcessor::createEditor()
{
    return new SmartArrangerAudioProcessorEditor (*this);
}

bool SmartArrangerAudioProcessor::hasEditor() const { return true; }
const juce::String SmartArrangerAudioProcessor::getName() const { return JucePlugin_Name; }
bool SmartArrangerAudioProcessor::acceptsMidi() const { return true; }
bool SmartArrangerAudioProcessor::producesMidi() const { return true; }
bool SmartArrangerAudioProcessor::isMidiEffect() const { return true; }
double SmartArrangerAudioProcessor::getTailLengthSeconds() const { return 0.0; }

int SmartArrangerAudioProcessor::getNumPrograms() { return 1; }
int SmartArrangerAudioProcessor::getCurrentProgram() { return 0; }
void SmartArrangerAudioProcessor::setCurrentProgram (int) {}
const juce::String SmartArrangerAudioProcessor::getProgramName (int) { return {}; }
void SmartArrangerAudioProcessor::changeProgramName (int, const juce::String&) {}

void SmartArrangerAudioProcessor::getStateInformation (juce::MemoryBlock& destination)
{
    if (const auto xml = parameters.copyState().createXml())
        copyXmlToBinary (*xml, destination);
}

void SmartArrangerAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (const auto xml = getXmlFromBinary (data, sizeInBytes))
        if (xml->hasTagName (parameters.state.getType().toString()))
            parameters.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new SmartArrangerAudioProcessor();
}
