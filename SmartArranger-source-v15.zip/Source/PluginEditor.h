#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"
#include "StyleFile.h"

class SmartArrangerAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                                private juce::Timer
{
public:
    explicit SmartArrangerAudioProcessorEditor (SmartArrangerAudioProcessor& processor);
    void paint (juce::Graphics& graphics) override;
    void resized() override;
    void timerCallback() override;

private:
    void chooseStyleFile();
    void loadStyleFile (const juce::File& file);
    void activateStyleSection();
    void rebuildSectionButtons (int selectedIndex);
    void selectStyleSection (int index);

    SmartArrangerAudioProcessor& targetProcessor;
    juce::TextButton loadStyleButton { "Load Yamaha .STY" };
    juce::OwnedArray<juce::TextButton> sectionButtons;
    juce::ToggleButton accompanimentButton { "ACCOMPANIMENT  OFF" };
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> accompanimentAttachment;
    std::unique_ptr<juce::FileChooser> fileChooser;
    juce::String styleSummary { "No style loaded" };
    juce::String styleTitle { "NO STYLE LOADED" };
    juce::String styleDetails;
    juce::String styleError;
    juce::String loadedStylePath;
    juce::String lastRestoreAttemptPath;
    SmartArrangerStyleInfo loadedStyleInfo;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (SmartArrangerAudioProcessorEditor)
};
