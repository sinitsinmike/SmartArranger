#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"
#include "StyleFile.h"

class SmartArrangerAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                                private juce::Timer
{
public:
    explicit SmartArrangerAudioProcessorEditor (SmartArrangerAudioProcessor& processor);
    void paint (juce::Graphics& graphics) override;
    void resized() override;
    void timerCallback() override;

private:
    void chooseStyleFile();
    void loadStyleFile (const juce::File& file);

    SmartArrangerAudioProcessor& targetProcessor;
    juce::TextButton loadStyleButton { "Load Yamaha .STY" };
    juce::ToggleButton accompanimentButton { "Enable basic accompaniment" };
    std::unique_ptr<juce::FileChooser> fileChooser;
    juce::String styleSummary { "No style loaded" };
    juce::String styleDetails;
    juce::String styleError;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (SmartArrangerAudioProcessorEditor)
};
