#pragma once

#include <JuceHeader.h>
#include <array>
#include <atomic>
#include <cstdint>

class SmartArrangerAudioProcessor final : public juce::AudioProcessor
{
public:
    SmartArrangerAudioProcessor();

    void prepareToPlay (double sampleRate, int maximumExpectedSamplesPerBlock) override;
    void releaseResources() override;
    void processBlock (juce::AudioBuffer<float>& audio, juce::MidiBuffer& midi) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override;

    const juce::String getName() const override;
    bool acceptsMidi() const override;
    bool producesMidi() const override;
    bool isMidiEffect() const override;
    double getTailLengthSeconds() const override;

    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram (int index) override;
    const juce::String getProgramName (int index) override;
    void changeProgramName (int index, const juce::String& newName) override;

    void getStateInformation (juce::MemoryBlock& destination) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    int getDetectedChordRoot() const noexcept;
    int getDetectedChordQuality() const noexcept;
    void setAccompanimentEnabled (bool shouldEnable) noexcept;
    bool isAccompanimentEnabled() const noexcept;

    enum ChordQuality
    {
        noChord = 0,
        major,
        minor,
        diminished,
        augmented,
        suspendedSecond,
        suspendedFourth,
        dominantSeventh,
        majorSeventh,
        minorSeventh,
        halfDiminishedSeventh,
        diminishedSeventh
    };

private:
    void updateDetectedChord() noexcept;
    void renderAccompaniment (juce::MidiBuffer& midi, int blockSamples) noexcept;

    // MIDI events are consumed and updated on the audio thread. The editor
    // reads only the atomics, so no UI lock is taken by processBlock().
    std::array<uint8_t, 16 * 128> heldNotes {};
    std::atomic<int> detectedChordRoot { -1 };
    std::atomic<int> detectedChordQuality { noChord };
    std::atomic<bool> accompanimentEnabled { false };
    std::array<uint8_t, 5> activeGeneratedNotes { 255, 255, 255, 255, 255 };
    int64_t lastGeneratedEighth = -1;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (SmartArrangerAudioProcessor)
};
