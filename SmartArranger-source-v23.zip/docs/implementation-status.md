# Implementation status — source archive v23

## Increment 1: live chord display

- Pass incoming MIDI through while tracking held notes by channel and pitch.
- Recognize common major, minor, diminished, augmented, suspended, and seventh-chord pitch-class patterns.
- Display the current estimate in the AU editor using atomic state polled by the UI.

### Current limits

- The detector examines all held notes across all channels; melody notes, inversions, extensions, and ambiguous collections can confuse it.
- Lowest held MIDI note is now reported separately from the detected chord root, so a bass inversion does not itself force the root estimate. This is only a partial improvement; selectable chord/bass input channels and Yamaha fingering-mode behavior remain unimplemented.
- Keyboard split zones and selectable fingering modes are not implemented.
- The chord detector and its musical behavior still need direct verification in Logic.

## Increment 2: Yamaha-style file inspection

- Load a user-selected style file and read its title, tempo, meter, section markers, MIDI channels, and event ranges.
- Parse the leading MIDI data with bounded readers and skip length-prefixed non-MIDI chunks.
- Preserve length-checked raw CASM records and nested records for each CSEG in the loaded style snapshot.
- Decode Sdec section names, the common Ctab/Ctb2 channel-table prefix, observed 27/31-byte Ctab transposition fields, and the documented 47-byte Ctb2 zones while retaining every original payload byte.
- Keep Cntt's observed two-byte pair opaque and preserve unrecognized record lengths without assigning playback meaning.
- Preserve the local style path and selected section index in project state.
- Display MIDI channels, CASM part labels, and embedded standard MIDI Program Change values in the editor when present. Unsupported Yamaha bank/voice data is not guessed.
- Group visible section buttons in arranger order so Intro A and Intro B are adjacent; START/STOP labels use plain text to avoid broken symbol rendering.

### Current limits

- The parser was smoke-checked against five local user-provided files (four SFF2 and one SFF1); they are not verified official Yamaha files and are not included in the repository or artifacts.
- The newer CASM field decoder has not yet been checked against those files or an official PSR-SX920/SX720 style corpus.
- Decoded CASM fields are inspection data only. Per-part NTR/NTT/RTR playback, chord-mask source selection, multi-source layering, and mapping style sections to CSEG entries are not implemented yet.
- The 27/31-byte Ctab and 47-byte Ctb2 layouts are scoped profiles, not a claim that every Yamaha generation or SFF dialect has these exact lengths.
- Style load/restore and scheduling need broader real-file verification in Logic.

## Increment 3: accompaniment and style playback

- Generate a simple fallback bass/chord pattern when no style is loaded.
- Play MIDI events from a loaded style, preserving channels, program changes, and other non-note messages.
- Use an internal audio-block clock, following host tempo/meter when available and style metadata otherwise.
- Keep the plugin START/STOP control independent from Logic's transport.

### Current limits

- The fallback pattern is a demonstration, not a full arranger pattern.
- Whether Logic continues calling this MIDI effect while transport is stopped must be checked on the target setup.
- A MIDI effect cannot create Logic tracks or instantiate multi-part instrument patches by itself.

## Increment 4: basic chord-following

- Retain the latest recognized chord after input notes are released.
- Transform imported style notes from a C-major reference to the detected root and basic chord quality.
- Apply harmony changes at arranger bar boundaries and release notes using the output pitches that were actually started.

### Current limits

- This is a global transform; it does not implement Yamaha's part-specific CASM/NTR/NTT/RTR behavior.
- The current root detector is still a common-chord pitch-class heuristic; it is not yet validated against the PSR-SX920/SX720 chord recognition modes.
- Passing chords, independent melody treatment, voice leading, and per-part transposition are not implemented.

## Increment 5: bar-aware section flow

- Load MIDI events for all named sections into an immutable playback snapshot.
- Queue section-button requests made during playback for the next bar boundary.
- Play Intro once, then move to the last selected Main variation (or the first Main if none was selected).
- Play Fill and Break once, then return to Main.
- Play Ending once, release active notes, and stop accompaniment.
- Loop Main and unclassified sections. Stop releases generated notes and clears pending transitions.

### Current limits

- Section roles are inferred from marker names; unusual naming may classify incorrectly.
- Fill/Break/Ending transitions and automatic Intro-to-Main flow still need validation with real Yamaha-style files in Logic.
- Transition timing currently uses the host meter when supplied, otherwise the style meter. Logic transport synchronization remains a future opt-in mode; current START/STOP remains independent.

## Future recording and synchronization modes

- Keep two recording options in scope: capture the complete generated MIDI arrangement, or capture the performed chord/control events and regenerate the style on playback.
- Add a separate Sync On/Off mode for Logic tempo, meter, and transport when recording. Preserve the independent arranger transport when Sync is off.
- Record section-button actions as replayable MIDI events or automation. This is a design target, not implemented behavior.

## Build and compatibility

- The current GitHub Actions workflow builds an Intel x86_64 AU with a macOS 10.13 deployment target.
- An earlier local source snapshot was configured and built with JUCE 9.0.4 and Apple Clang 15 as a Mach-O x86_64 AU with a macOS 10.13 deployment target. That bundle is not code-signed or notarized.
- The current CASM decoder and chord-state changes have not been compiled or loaded in Logic Pro. The user-reported Apple Silicon launch was of an earlier build.
- The latest UI updates for grouped sections, text-only transport labels, and channel/program summary still need a new build and Logic verification.
- Previous Apple Silicon builds and the user's Logic launch demonstrate that the plugin can load in that tested setup; every new behavior still needs host verification.
- No style files are bundled with the repository or artifacts.

## Visual polish backlog

- The section button grid protrudes slightly beyond the section panel horizontally.
- The accompaniment toggle is too close to the top row of section buttons and sits slightly high.
- Rework horizontal margins and vertical spacing together in a later UI pass.
