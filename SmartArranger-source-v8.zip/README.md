# Smart Arranger

Smart Arranger is planned as a live AU MIDI arranger for Logic Pro. It will play imported style parts while the user performs chords on a MIDI keyboard.

The product requirements and compatibility target are in [Smart_Arranger.md](Smart_Arranger.md). The supplied interface image is a visual reference, not a final design specification.

## Current status

The AU prototype has been built successfully on GitHub Actions for Intel macOS and loaded in Logic Pro on the user's Apple Silicon Mac. The current increments observe incoming MIDI, display a live chord estimate, inspect Yamaha style metadata and retain its MIDI events in memory, and optionally add a host-synchronized 4/4 bass-and-chord pattern. Its accompaniment switch is a Logic-automatable parameter saved with the host project.

This is still an early prototype: chord recognition uses pitch classes; style inspection is metadata-only and has not yet been validated against a user-provided style file. The generated pattern is not based on the loaded Yamaha style; it does not yet apply Yamaha CASM/NTR/NTT rules, switch sections, or route separate parts. The Intel AU is not a native Apple Silicon build. The repository workflow retains downloadable build artifacts.

See [docs/environment-assessment.md](docs/environment-assessment.md) and [docs/compatibility-research.md](docs/compatibility-research.md) for observed setup, source findings, and remaining host checks.

## Compatibility targets

- Required: Intel x86_64, macOS High Sierra 10.13, Logic Pro 10.4.4
- Additional: Apple Silicon Logic Pro; currently loaded successfully on the user's Mac, but the active architecture/Rosetta mode has not been determined
- Framework: JUCE 9.0.4

## Project rule

Do not claim support for a style format, AU MIDI routing behavior, or target OS until it has been verified with real files and on the target setup. Keep the live chord detector clearly labeled as preliminary until validated against musical test cases.
