# Implementation status

## Increment 1: live chord display

- Observe Note On/Off events in the incoming MIDI stream without modifying the stream.
- Track held notes by MIDI channel and note number.
- Recognize common major, minor, diminished, augmented, suspended, and seventh-chord pitch-class patterns.
- Display the current estimate in the AU editor.
- Keep the audio callback free of UI locks; the editor polls atomic chord state.

### Current limits

- The detector examines all held notes and can misidentify extensions, melody notes, inversions, or ambiguous pitch collections.
- The chord detector provides the harmony estimate used by the basic generator, but is not yet used to adapt imported style material.
- No `.STY` parser, style playback, section transitions, or multi-part routing is implemented.
- Compilation proves the AU target builds, not that this detector has been musically validated in Logic.

## Increment 2: style metadata inspection

- Add a file picker for `.STY` files.
- Parse the leading MIDI header and one format-0 MIDI track using bounded readers.
- Read tempo, meter, section marker ranges, MIDI channels containing notes, and whether a CASM block exists.
- Preserve channel MIDI events with absolute ticks, raw status/data bytes, and section index for the playback engine.
- Skip length-prefixed non-MIDI sections without attempting to interpret their rules.

### Current limits

- The parser has not yet been checked against an actual user `.STY` file, so its supported subset is provisional.
- It does not schedule the preserved style events, interpret CASM/NTR/NTT/RTR, or change MIDI output.
- Displayed MIDI channel count is only an observed channel count; it is not a Yamaha part-name mapping.

## Increment 3: host-synchronized basic accompaniment

- Add an opt-in accompaniment switch in the editor.
- Keep the most recently recognized chord after the performed chord is released.
- Generate a basic 4/4 pattern: bass on beats 1 and 3, chord stabs on 2 and 4.
- Schedule generated MIDI from Logic's PPQ position and tempo; release generated notes when stopped or disabled.

### Current limits

- This is a fixed demonstration pattern, not a Yamaha style playback engine.
- Chord changes inside a MIDI block are applied at block granularity.
- Meter is fixed at 4/4. Voicing, voice-leading, fills, sections, part assignment, and CASM rules are not implemented.
- Host PPQ/tempo delivery and generated MIDI behavior still need direct Logic verification.

## Increment 4: host parameter and project state

- Expose accompaniment enable as a JUCE parameter, allowing Logic automation.
- Bind the editor toggle to the parameter attachment.
- Save and restore the parameter through the processor state so projects reopen consistently.

### Current limits

- The loaded style path and selected section are not yet saved because styles do not drive playback.
- State currently contains the accompaniment switch only; future engine settings should join the same state tree.

## Next increments

1. Validate the metadata reader with real SFF1/SFF2 `.STY` files and harden it against variants.
2. Map the preserved events, MIDI channels, and sections to actual style parts.
3. Add synchronized playback of one unchanged style section.
4. Add chord adaptation from the style's CASM rules.
5. Add section transitions only after playback timing is reliable.
