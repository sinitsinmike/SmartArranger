#include "PluginEditor.h"

#include <algorithm>

namespace
{
const juce::Colour background (0xff0b1118);
const juce::Colour panel (0xff171d23);
const juce::Colour panelEdge (0xff665238);
const juce::Colour muted (0xffb8aa91);
const juce::Colour cyan (0xff67b8d5);
const juce::Colour gold (0xffe9b85b);

juce::String getChordLabel (int root, int quality)
{
    if (root < 0 || root > 11)
        return "N/C";

    static const char* noteNames[] = { "C", "C#", "D", "D#", "E", "F",
                                       "F#", "G", "G#", "A", "A#", "B" };
    static const char* suffixes[] = { "", "", "m", "dim", "aug", "sus2", "sus4",
                                      "7", "maj7", "m7", "m7b5", "dim7" };
    if (quality < 0 || quality >= 12)
        return "N/C";
    return juce::String (noteNames[root]) + suffixes[quality];
}

void styleButton (juce::TextButton& button, juce::Colour colour)
{
    button.setColour (juce::TextButton::buttonColourId, panel.brighter (0.12f));
    button.setColour (juce::TextButton::buttonOnColourId, colour.withAlpha (0.98f));
    button.setColour (juce::TextButton::textColourOffId, juce::Colour (0xffeee7d8));
    button.setColour (juce::TextButton::textColourOnId, juce::Colour (0xff21180c));
    button.setClickingTogglesState (true);
}

int sectionDisplayGroup (const juce::String& name)
{
    const auto folded = name.toLowerCase();
    if (folded.startsWith ("sint")) return 0;
    if (folded.startsWith ("intro")) return 1;
    if (folded.startsWith ("main")) return 2;
    if (folded.startsWith ("fill")) return 3;
    if (folded.startsWith ("break")) return 4;
    if (folded.startsWith ("ending")) return 5;
    return 6;
}

juce::String gmProgramName (int program)
{
    static const char* names[] = {
        "Piano", "Bright Piano", "Electric Grand", "Honky-tonk", "EP 1", "EP 2", "Harpsichord", "Clav",
        "Celesta", "Glockenspiel", "Music Box", "Vibraphone", "Marimba", "Xylophone", "Tubular Bells", "Dulcimer",
        "Drawbar Organ", "Percussive Organ", "Rock Organ", "Church Organ", "Reed Organ", "Accordion", "Harmonica", "Tango Accordion",
        "Nylon Guitar", "Steel Guitar", "Jazz Guitar", "Clean Guitar", "Muted Guitar", "Overdrive Guitar", "Distortion Guitar", "Guitar Harmonics",
        "Acoustic Bass", "Finger Bass", "Pick Bass", "Fretless Bass", "Slap Bass 1", "Slap Bass 2", "Synth Bass 1", "Synth Bass 2",
        "Violin", "Viola", "Cello", "Contrabass", "Tremolo Strings", "Pizzicato Strings", "Harp", "Timpani",
        "Strings", "Slow Strings", "Synth Strings 1", "Synth Strings 2", "Choir Aahs", "Voice Oohs", "Synth Voice", "Orchestra Hit",
        "Trumpet", "Trombone", "Tuba", "Muted Trumpet", "French Horn", "Brass Section", "Synth Brass 1", "Synth Brass 2",
        "Soprano Sax", "Alto Sax", "Tenor Sax", "Baritone Sax", "Oboe", "English Horn", "Bassoon", "Clarinet",
        "Piccolo", "Flute", "Recorder", "Pan Flute", "Bottle", "Shakuhachi", "Whistle", "Ocarina",
        "Square Lead", "Saw Lead", "Calliope Lead", "Chiff Lead", "Charang Lead", "Voice Lead", "Fifths Lead", "Bass + Lead",
        "New Age Pad", "Warm Pad", "Polysynth Pad", "Choir Pad", "Bowed Pad", "Metallic Pad", "Halo Pad", "Sweep Pad",
        "Rain FX", "Soundtrack FX", "Crystal FX", "Atmosphere FX", "Brightness FX", "Goblins FX", "Echoes FX", "Sci-fi FX",
        "Sitar", "Banjo", "Shamisen", "Koto", "Kalimba", "Bagpipe", "Fiddle", "Shanai",
        "Tinkle Bell", "Agogo", "Steel Drums", "Woodblock", "Taiko Drum", "Melodic Tom", "Synth Drum", "Reverse Cymbal",
        "Guitar Fret Noise", "Breath Noise", "Seashore", "Bird", "Telephone", "Helicopter", "Applause", "Gunshot"
    };
    return program >= 0 && program < 128 ? juce::String (names[program]) : juce::String ("unknown");
}
}

SmartArrangerAudioProcessorEditor::SmartArrangerAudioProcessorEditor (
    SmartArrangerAudioProcessor& processorToUse)
    : juce::AudioProcessorEditor (processorToUse), targetProcessor (processorToUse)
{
    setSize (760, 510);
    addAndMakeVisible (loadStyleButton);
    loadStyleButton.onClick = [this] { chooseStyleFile(); };
    loadStyleButton.setColour (juce::TextButton::buttonColourId, juce::Colour (0xff34291c));
    loadStyleButton.setColour (juce::TextButton::textColourOffId, juce::Colour (0xffffe6b2));

    addAndMakeVisible (accompanimentButton);
    accompanimentButton.setClickingTogglesState (true);
    accompanimentButton.setColour (juce::TextButton::buttonColourId, panel.brighter (0.12f));
    accompanimentButton.setColour (juce::TextButton::buttonOnColourId, juce::Colour (0xffe9b85b));
    accompanimentButton.setColour (juce::TextButton::textColourOffId, juce::Colour (0xffeee7d8));
    accompanimentButton.setColour (juce::TextButton::textColourOnId, juce::Colour (0xff21180c));
    accompanimentAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (
        targetProcessor.getParameterState(), "accompanimentEnabled", accompanimentButton);
    startTimerHz (20);
}

void SmartArrangerAudioProcessorEditor::resized()
{
    auto area = getLocalBounds().reduced (22);
    auto header = area.removeFromTop (54);
    loadStyleButton.setBounds (header.removeFromRight (174).reduced (0, 6));
    area.removeFromTop (80);
    area.removeFromTop (18);
    auto sections = area.removeFromTop (218);
    sections.removeFromTop (34);
    accompanimentButton.setBounds (getWidth() - 220, 178, 178, 30);
    const int columns = 4;
    const int gap = 9;
    const int rows = juce::jmax (1, (sectionButtons.size() + columns - 1) / columns);
    const int buttonHeight = juce::jmin (44, (sections.getHeight() - gap * (rows - 1)) / rows);
    for (int i = 0; i < sectionButtons.size(); ++i)
    {
        const int row = i / columns;
        const int column = i % columns;
        const int width = (sections.getWidth() - gap * (columns - 1)) / columns;
        sectionButtons[i]->setBounds (sections.getX() + column * (width + gap),
                                      sections.getY() + row * (buttonHeight + gap),
                                      width, buttonHeight);
    }
}

void SmartArrangerAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (background);
    auto bounds = getLocalBounds().reduced (12);
    g.setGradientFill (juce::ColourGradient (juce::Colour (0xff1a2026), 0.0f, 0.0f,
                                             juce::Colour (0xff0c1218), 0.0f,
                                             (float) getHeight(), false));
    g.fillRoundedRectangle (bounds.toFloat(), 16.0f);
    g.setColour (panelEdge);
    g.drawRoundedRectangle (bounds.toFloat(), 16.0f, 1.5f);
    g.setColour (gold.withAlpha (0.18f));
    g.drawRoundedRectangle (bounds.reduced (4).toFloat(), 13.0f, 0.7f);

    g.setColour (juce::Colour (0xffedf5fb));
    g.setFont (juce::Font (25.0f, juce::Font::bold));
    g.drawText ("SMART", 28, 17, 102, 34, juce::Justification::centredLeft);
    g.setColour (gold);
    g.drawText ("ARRANGER", 128, 17, 175, 34, juce::Justification::centredLeft);
    const juce::Rectangle<float> titleCard (310.0f, 12.0f, 238.0f, 48.0f);
    g.setColour (juce::Colour (0xff211c15));
    g.fillRoundedRectangle (titleCard, 9.0f);
    g.setColour (gold.withAlpha (0.60f));
    g.drawRoundedRectangle (titleCard, 9.0f, 1.0f);
    g.setColour (muted);
    g.setFont (juce::Font (9.0f, juce::Font::bold));
    g.drawText ("STYLE", 323, 15, 210, 12, juce::Justification::centredLeft);
    g.setColour (juce::Colour (0xffedf5fb));
    g.setFont (juce::Font (13.0f, juce::Font::bold));
    g.drawFittedText (styleTitle, 323, 28, 210, 21,
                      juce::Justification::centredLeft, 1);

    auto styleCard = juce::Rectangle<int> (26, 76, getWidth() - 52, 80);
    g.setGradientFill (juce::ColourGradient (juce::Colour (0xff242a30), 26.0f, 76.0f,
                                             juce::Colour (0xff11171d), 26.0f,
                                             156.0f, false));
    g.fillRoundedRectangle (styleCard.toFloat(), 12.0f);
    g.setColour (gold.withAlpha (0.48f));
    g.drawRoundedRectangle (styleCard.toFloat(), 12.0f, 1.2f);
    g.setColour (juce::Colour (0xfff2f7fb));
    g.setFont (juce::Font (19.0f, juce::Font::bold));
    g.drawText (styleSummary, 42, 86, getWidth() - 250, 30,
                juce::Justification::centredLeft, true);
    g.setColour (styleError.isEmpty() ? muted : juce::Colour (0xffff8c83));
    g.setFont (juce::Font (12.0f));
    g.drawText (styleError.isNotEmpty() ? styleError : styleDetails,
                42, 116, getWidth() - 84, 17, juce::Justification::centredLeft, true);
    if (styleError.isEmpty() && channelDetails.isNotEmpty())
    {
        g.setColour (muted);
        g.setFont (juce::Font (9.5f));
        g.drawFittedText (channelDetails, 42, 131, getWidth() - 84, 23,
                          juce::Justification::centredLeft, 2);
    }

    g.setColour (juce::Colour (0xff151b21));
    g.fillRoundedRectangle (26.0f, 174.0f, (float) getWidth() - 52.0f, 225.0f, 12.0f);
    g.setColour (gold.withAlpha (0.40f));
    g.drawRoundedRectangle (26.0f, 174.0f, (float) getWidth() - 52.0f, 225.0f, 12.0f, 1.2f);
    g.setColour (gold);
    g.setFont (juce::Font (12.0f, juce::Font::bold));
    g.drawText ("STYLE SECTIONS", 42, 184, 200, 22, juce::Justification::centredLeft);
    if (sectionButtons.isEmpty())
    {
        g.setColour (muted);
        g.setFont (juce::Font (15.0f));
        g.drawFittedText ("LOAD A STYLE FILE TO SHOW INTRO, MAIN, FILL AND ENDING SECTIONS",
                          42, 235, getWidth() - 84, 42, juce::Justification::centred, 1);
    }

    const int chordTop = 420;
    g.setColour (juce::Colour (0xff151b21));
    g.fillRoundedRectangle (26.0f, (float) chordTop, (float) getWidth() - 52.0f, 64.0f, 12.0f);
    g.setColour (gold.withAlpha (0.43f));
    g.drawRoundedRectangle (26.0f, (float) chordTop, (float) getWidth() - 52.0f, 64.0f, 12.0f, 1.1f);
    g.setColour (gold);
    g.setFont (juce::Font (11.0f, juce::Font::bold));
    g.drawText ("LIVE CHORD", 42, chordTop + 8, 100, 18, juce::Justification::centredLeft);
    g.setColour (juce::Colour (0xfff1f6fa));
    g.setFont (juce::Font (27.0f, juce::Font::bold));
    g.drawText (getChordLabel (targetProcessor.getDetectedChordRoot(),
                               targetProcessor.getDetectedChordQuality()),
                42, chordTop + 24, 105, 32, juce::Justification::centredLeft);
    g.setColour (muted);
    g.setFont (juce::Font (12.0f));
    g.drawFittedText ("Play a chord in Logic. The latest recognized harmony stays active.",
                      160, chordTop + 18, getWidth() - 206, 32,
                      juce::Justification::centredLeft, 1);
}

void SmartArrangerAudioProcessorEditor::chooseStyleFile()
{
    fileChooser = std::make_unique<juce::FileChooser> ("Choose a Yamaha Style file",
        juce::File(), "*.sty;*.STY;*.prs;*.PRS;*.bcs;*.BCS;*.sst;*.SST;*.scp;*.SCP;*.fps;*.FPS;*.aus;*.AUS");
    juce::Component::SafePointer<SmartArrangerAudioProcessorEditor> safeThis (this);
    fileChooser->launchAsync (juce::FileBrowserComponent::openMode
                                  | juce::FileBrowserComponent::canSelectFiles,
                              [safeThis] (const juce::FileChooser& chooser)
                              {
                                  if (safeThis != nullptr && chooser.getResult().existsAsFile())
                                      safeThis->loadStyleFile (chooser.getResult());
                              });
}

void SmartArrangerAudioProcessorEditor::loadStyleFile (const juce::File& file)
{
    lastRestoreAttemptPath = file.getFullPathName();
    SmartArrangerStyleInfo info;
    juce::String error;
    if (! SmartArrangerStyleFile::inspect (file, info, error))
    {
        const bool retryingSavedStyle = file.getFullPathName() == targetProcessor.getStoredStylePath();
        if (! retryingSavedStyle)
            targetProcessor.clearLoadedStyle();
        loadedStyleInfo = {};
        sectionButtons.clear (true);
        sectionButtonToStyleIndex.clear();
        styleTitle = "STYLE NOT LOADED";
        styleSummary = "Could not load " + file.getFileName();
        styleDetails.clear();
        channelDetails.clear();
        styleError = error;
        resized(); repaint();
        return;
    }

    loadedStyleInfo = std::move (info);
    loadedStylePath = file.getFullPathName();
    const bool restoringSameStyle = loadedStylePath == targetProcessor.getStoredStylePath();
    const int sectionToLoad = restoringSameStyle
        ? juce::jlimit (0, (int) loadedStyleInfo.sections.size() - 1,
                        targetProcessor.getStoredStyleSection()) : 0;
    rebuildSectionButtons (sectionToLoad);
    if (! targetProcessor.setLoadedStyle (loadedStyleInfo, sectionToLoad, error, file))
    {
        targetProcessor.clearLoadedStyle();
        styleTitle = loadedStyleInfo.name;
        styleSummary = "Style parsed";
        styleDetails.clear();
        styleError = error;
        resized(); repaint();
        return;
    }

    int channels = 0;
    for (int channel = 0; channel < 16; ++channel)
        if ((loadedStyleInfo.usedChannels & (1u << channel)) != 0) ++channels;
    styleTitle = loadedStyleInfo.name;
    styleSummary = loadedStyleInfo.format + " | "
                 + juce::String (loadedStyleInfo.tempo) + " BPM | "
                 + juce::String (loadedStyleInfo.numerator) + "/" + juce::String (loadedStyleInfo.denominator);
    styleDetails = juce::String ((int) loadedStyleInfo.sections.size()) + " sections | "
                 + juce::String (channels) + " MIDI channels | "
                 + juce::String ((int) loadedStyleInfo.events.size()) + " events";

    std::array<int, 16> programs;
    programs.fill (-1);
    std::array<juce::String, 16> parts;
    for (const auto& segment : loadedStyleInfo.casmSegments)
        for (const auto& record : segment.records)
            if (record.hasCommonChannelFields)
            {
                const int source = record.sourceChannel == 0 ? 0 : (int) record.sourceChannel - 1;
                if (source >= 0 && source < 16 && parts[(size_t) source].isEmpty())
                    parts[(size_t) source] = record.partLabel.trim();
            }
    for (const auto& event : loadedStyleInfo.events)
        if ((event.status & 0xf0u) == 0xc0u)
            programs[(size_t) (event.status & 0x0fu)] = event.data1;
    channelDetails.clear();
    for (int channel = 0; channel < 16; ++channel)
    {
        if ((loadedStyleInfo.usedChannels & (1u << channel)) == 0) continue;
        if (channelDetails.isNotEmpty()) channelDetails += "   |   ";
        channelDetails += "Ch " + juce::String (channel + 1);
        if (parts[(size_t) channel].isNotEmpty())
            channelDetails += " " + parts[(size_t) channel];
        if (programs[(size_t) channel] >= 0)
            channelDetails += ": " + gmProgramName (programs[(size_t) channel])
                           + " (PC " + juce::String (programs[(size_t) channel] + 1) + ")";
        else
            channelDetails += ": program not specified";
    }
    styleError.clear();
    resized(); repaint();
}

void SmartArrangerAudioProcessorEditor::rebuildSectionButtons (int selectedIndex)
{
    sectionButtons.clear (true);
    sectionButtonToStyleIndex.clear();
    std::vector<int> displayOrder (loadedStyleInfo.sections.size());
    for (int i = 0; i < (int) displayOrder.size(); ++i) displayOrder[(size_t) i] = i;
    std::stable_sort (displayOrder.begin(), displayOrder.end(), [this] (int a, int b)
    {
        const auto& first = loadedStyleInfo.sections[(size_t) a].name;
        const auto& second = loadedStyleInfo.sections[(size_t) b].name;
        const int firstGroup = sectionDisplayGroup (first);
        const int secondGroup = sectionDisplayGroup (second);
        return firstGroup != secondGroup ? firstGroup < secondGroup
                                         : first.compareNatural (second) < 0;
    });
    for (const int i : displayOrder)
    {
        const auto& section = loadedStyleInfo.sections[(size_t) i];
        const auto name = section.name;
        auto* button = sectionButtons.add (new juce::TextButton (name));
        auto sectionLength = section.lengthTicks;
        if (sectionLength == 0 && loadedStyleInfo.totalTicks > section.startTick)
            sectionLength = loadedStyleInfo.totalTicks - section.startTick;
        const auto sectionEnd = section.startTick + sectionLength;
        const bool hasEvents = sectionLength > 0 && std::any_of (
            loadedStyleInfo.events.begin(), loadedStyleInfo.events.end(), [i, &section, sectionEnd] (const auto& event)
            {
                const bool fallbackTrack = section.name == "Track" && event.sectionIndex < 0;
                return (fallbackTrack || event.sectionIndex == i)
                    && event.tick >= section.startTick && event.tick < sectionEnd;
            });
        button->setEnabled (hasEvents);
        const auto folded = name.toLowerCase();
        const auto accent = folded.contains ("intro") ? cyan
                          : (folded.contains ("main") ? gold
                          : (folded.contains ("fill") ? juce::Colour (0xff529aff)
                          : (folded.contains ("break") ? juce::Colour (0xffc27bff)
                          : (folded.contains ("end") ? juce::Colour (0xffff776e) : cyan))));
        styleButton (*button, accent);
        button->setRadioGroupId (7001);
        button->setToggleState (i == selectedIndex, juce::dontSendNotification);
        sectionButtonToStyleIndex.add (i);
        button->onClick = [this, i] { selectStyleSection (i); };
        addAndMakeVisible (button);
    }
    resized();
}

void SmartArrangerAudioProcessorEditor::selectStyleSection (int index)
{
    if (index < 0 || index >= (int) loadedStyleInfo.sections.size()) return;
    targetProcessor.requestStyleSection (index);
    styleError.clear();
    repaint();
}

void SmartArrangerAudioProcessorEditor::activateStyleSection()
{
    selectStyleSection (0);
}

void SmartArrangerAudioProcessorEditor::timerCallback()
{
    if (targetProcessor.hasStylePlaybackFinished() && targetProcessor.isAccompanimentEnabled())
        targetProcessor.setAccompanimentEnabled (false);
    const int displayedSection = targetProcessor.getRequestedStyleSection();
    if (displayedSection >= 0 && displayedSection < loadedStyleInfo.sections.size())
    {
        for (int i = 0; i < sectionButtons.size(); ++i)
            sectionButtons[i]->setToggleState (sectionButtonToStyleIndex[i] == displayedSection,
                                               juce::dontSendNotification);
        if (displayedSection != targetProcessor.getStoredStyleSection())
            targetProcessor.requestStyleSection (displayedSection);
    }
    accompanimentButton.setButtonText (accompanimentButton.getToggleState() ? "STOP" : "START");
    const auto storedPath = targetProcessor.getStoredStylePath();
    if (storedPath.isNotEmpty() && storedPath != loadedStylePath
        && storedPath != lastRestoreAttemptPath)
    {
        loadStyleFile (juce::File (storedPath));
        return;
    }
    repaint();
}
