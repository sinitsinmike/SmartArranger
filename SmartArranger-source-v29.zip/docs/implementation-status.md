# Implementation status — source archive v29

## Increment 1: live chord display

- Pass incoming MIDI through while tracking held notes by channel and pitch.
- Recognize common major, minor, diminished, augmented, suspended, and seventh-chord pitch-class patterns.
- Display the current estimate in the AU editor using atomic state polled by the UI.

### Current limits

- The detector examines all held notes across all channels; melody notes, inversions, extensions, and ambiguous collections can confuse it.
- Lowest held MIDI note is now reported separately from the detected chord root, so a bass inversion does not itself force the root estimate. This is only a partial improvement; selectable chord/bass input channels and Yamaha fingering-mode behavior remain unimplemented.
- Keyboard split zones and selectable fingering modes are not implemented.
- The chord detector and its musical behavior still need direct verification in Logic.

## Increment 2: Yamaha-style file inspection

- Load a user-selected style file and read its title, tempo, meter, section markers, MIDI channels, and event ranges.
- Parse the leading MIDI data with bounded readers and skip length-prefixed non-MIDI chunks.
- Preserve length-checked raw CASM records and nested records for each CSEG in the loaded style snapshot.
- Decode Sdec section names, the common Ctab/Ctb2 channel-table prefix, observed 27/31-byte Ctab transposition fields, and the documented 47-byte Ctb2 zones while retaining every original payload byte.
- Keep Cntt's observed two-byte pair opaque and preserve unrecognized record lengths without assigning playback meaning.
- Preserve the local style path and selected section index in project state.
- Display MIDI channels, CASM part labels, and embedded standard MIDI Program Change values in the editor when present. Unsupported Yamaha bank/voice data is not guessed.
- Group visible section buttons in arranger order so Intro A and Intro B are adjacent; START/STOP labels use plain text to avoid broken symbol rendering.

### Current limits

- The parser was smoke-checked against five local user-provided files (four SFF2 and one SFF1); they are not verified official Yamaha files and are not included in the repository or artifacts.
- The newer CASM field decoder has not yet been checked against those files or an official PSR-SX920/SX720 style corpus.
- Source v28 builds an immutable per-section view that links source MIDI channels to CASM destinations and retains all matching records. This is metadata only: playback does not yet apply the linked rules, chord masks, or multi-source layering. Section names currently match case-insensitively after trimming; aliases are not guessed.
- The 27/31-byte Ctab and 47-byte Ctb2 layouts are scoped profiles, not a claim that every Yamaha generation or SFF dialect has these exact lengths.
- Style load/restore and scheduling need broader real-file verification in Logic.

## Increment 3: accompaniment and style playback

- Generate a simple fallback bass/chord pattern when no style is loaded.
- Play MIDI events from a loaded style, preserving channels, program changes, and other non-note messages.
- Use an internal audio-block clock, following host tempo/meter when available and style metadata otherwise.
- Keep the plugin START/STOP control independent from Logic's transport.

### Current limits

- The fallback pattern is a demonstration, not a full arranger pattern.
- Whether Logic continues calling this MIDI effect while transport is stopped must be checked on the target setup.
- A MIDI effect cannot create Logic tracks or instantiate multi-part instrument patches by itself.

## Increment 4: basic chord-following

- Retain the latest recognized chord after input notes are released.
- Transform imported style notes from a C-major reference to the detected root and basic chord quality.
- Apply harmony changes at arranger bar boundaries and release notes using the output pitches that were actually started.

### Current limits

- This is a global transform; it does not implement Yamaha's part-specific CASM/NTR/NTT/RTR behavior.
- The current root detector is still a common-chord pitch-class heuristic; it is not yet validated against the PSR-SX920/SX720 chord recognition modes.
- Passing chords, independent melody treatment, voice leading, and per-part transposition are not implemented.

## Increment 6: conservative SFF1 bypass transposition

- For a section/source channel with exactly one CASM destination and consistent decoded SFF1 records, apply `NTT Bypass` with `NTR Root Trans` as a semitone shift from the record's source root to the current detected chord root.
- `NTT Bypass` with `NTR Root Fixed` keeps the authored pitches, as described in Yamaha's reference manual.
- Mapped channels with unsupported, conflicting, or multiple destination rules pass through unchanged. Unmapped channels retain the earlier global prototype transform.
- Note-offs use the output pitch recorded for their corresponding note-on.

### Current limits

- This increment handles only SFF1 Bypass + Root Trans/Root Fixed. It does not implement NTT chord conversion, SFF2 zones, chord/note mask gating, RTR behavior, or routing to the logical Yamaha destination channel.
- Multi-source layering and a complete Yamaha fingering/chord recognition model remain future work.
- The code has not been built or checked in Logic. The rules need comparison against controlled reference fixtures before this increment is treated as validated.

## Increment 5: bar-aware section flow

- Load MIDI events for all named sections into an immutable playback snapshot.
- Queue section-button requests made during playback for the next bar boundary.
- Play Intro once, then move to the last selected Main variation (or the first Main if none was selected).
- Play Fill and Break once, then return to Main.
- Play Ending once, release active notes, and stop accompaniment.
- Loop Main and unclassified sections. Stop releases generated notes and clears pending transitions.

### Current limits

- Section roles are inferred from marker names; unusual naming may classify incorrectly.
- Fill/Break/Ending transitions and automatic Intro-to-Main flow still need validation with real Yamaha-style files in Logic.
- Transition timing currently uses the host meter when supplied, otherwise the style meter. Logic transport synchronization remains a future opt-in mode; current START/STOP remains independent.

## Future recording and synchronization modes

- Keep two recording options in scope: capture the complete generated MIDI arrangement, or capture the performed chord/control events and regenerate the style on playback.
- Add a separate Sync On/Off mode for Logic tempo, meter, and transport when recording. Preserve the independent arranger transport when Sync is off.
- Record section-button actions as replayable MIDI events or automation. This is a design target, not implemented behavior.

## Build and compatibility

- The current GitHub Actions workflow builds an Intel x86_64 AU with a macOS 10.13 deployment target.
- An earlier local source snapshot was configured and built with JUCE 9.0.4 and Apple Clang 15 as a Mach-O x86_64 AU with a macOS 10.13 deployment target. That bundle is not code-signed or notarized.
- The user confirmed that source v27 loaded in Logic and that sections switch and the arrangement responds to chord input. Source v28 added CASM metadata mapping; source v29 adds a limited SFF1 playback transform. Neither v28 nor v29 has been compiled or loaded in Logic Pro.
- Source v27 layout was verified by the user in Logic: section buttons and long style-name sizing display correctly. Source v28 adds the section/channel CASM mapping; that new code still needs a build and host check.
- Previous Apple Silicon builds and the user's Logic launch demonstrate that the plugin can load in that tested setup; every new behavior still needs host verification.
- No style files are bundled with the repository or artifacts.

## Visual polish

- Source v28 keeps section buttons inside their panel for large styles; the editor grows vertically as needed. Long style names expand the editor horizontally, with the title card staying aligned to Load. START/STOP sits in the section-panel header, away from section labels and Live Chord text.
- Channel rows show readable CASM part labels and instrument names inferred from standard MIDI Program Changes. PC numbers are omitted; Yamaha bank and model-specific voice decoding remains future work.
