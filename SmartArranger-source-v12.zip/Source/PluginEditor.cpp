#include "PluginEditor.h"

namespace
{
juce::String getChordLabel (int root, int quality)
{
    if (root < 0 || root > 11)
        return "—";

    static const char* noteNames[] = { "C", "C#", "D", "D#", "E", "F",
                                       "F#", "G", "G#", "A", "A#", "B" };
    static const char* suffixes[] = { "", "", "m", "dim", "aug", "sus2", "sus4",
                                      "7", "maj7", "m7", "m7b5", "dim7" };
    if (quality < 0 || quality >= 12)
        return "—";

    return juce::String (noteNames[root]) + suffixes[quality];
}
}

SmartArrangerAudioProcessorEditor::SmartArrangerAudioProcessorEditor (
    SmartArrangerAudioProcessor& processorToUse)
    : juce::AudioProcessorEditor (processorToUse), targetProcessor (processorToUse)
{
    setSize (560, 390);
    addAndMakeVisible (loadStyleButton);
    addAndMakeVisible (sectionSelector);
    sectionSelector.setTextWhenNothingSelected ("Choose section to play");
    sectionSelector.setVisible (false);
    sectionSelector.onChange = [this] { activateStyleSection(); };
    addAndMakeVisible (accompanimentButton);
    loadStyleButton.onClick = [this] { chooseStyleFile(); };
    accompanimentAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (
        targetProcessor.getParameterState(), "accompanimentEnabled", accompanimentButton);
    startTimerHz (20);
}

void SmartArrangerAudioProcessorEditor::resized()
{
    loadStyleButton.setBounds (getWidth() / 2 - 105, 72, 210, 34);
    sectionSelector.setBounds (getWidth() / 2 - 145, 112, 290, 30);
    accompanimentButton.setBounds (getWidth() / 2 - 145, 148, 290, 28);
}

void SmartArrangerAudioProcessorEditor::paint (juce::Graphics& graphics)
{
    graphics.fillAll (juce::Colour::fromRGB (16, 22, 30));
    graphics.setColour (juce::Colour::fromRGB (232, 237, 243));
    graphics.setFont (juce::Font (26.0f, juce::Font::bold));
    graphics.drawFittedText ("SMART ARRANGER", getLocalBounds().reduced (24, 28),
                             juce::Justification::centredTop, 1);

    graphics.setColour (juce::Colour::fromRGB (168, 185, 199));
    graphics.setFont (juce::Font (14.0f));
    graphics.drawFittedText (styleSummary,
                             getLocalBounds().withTrimmedTop (112).removeFromTop (24),
                             juce::Justification::centred, 1);
    graphics.setColour (styleError.isEmpty() ? juce::Colour::fromRGB (130, 151, 170)
                                              : juce::Colour::fromRGB (255, 137, 127));
    graphics.setFont (juce::Font (12.0f));
    graphics.drawFittedText (styleError.isEmpty() ? styleDetails : styleError,
                             getLocalBounds().withTrimmedTop (136).removeFromTop (32).reduced (22, 0),
                             juce::Justification::centred, 2);

    graphics.setColour (juce::Colour::fromRGB (111, 178, 242));
    graphics.setFont (juce::Font (15.0f, juce::Font::bold));
    graphics.drawFittedText ("LIVE CHORD", getLocalBounds().withTrimmedTop (184).removeFromTop (24),
                             juce::Justification::centred, 1);

    graphics.setColour (juce::Colour::fromRGB (245, 247, 250));
    graphics.setFont (juce::Font (42.0f, juce::Font::bold));
    graphics.drawFittedText (getChordLabel (targetProcessor.getDetectedChordRoot(),
                                            targetProcessor.getDetectedChordQuality()),
                             getLocalBounds().withTrimmedTop (206).removeFromTop (62),
                             juce::Justification::centred, 1);

    graphics.setColour (juce::Colour::fromRGB (168, 185, 199));
    graphics.setFont (juce::Font (15.0f));
    graphics.drawFittedText ("Play a chord into the MIDI effect; the latest recognized harmony is held",
                             getLocalBounds().withTrimmedTop (286).removeFromTop (28),
                             juce::Justification::centred, 1);
    graphics.drawFittedText ("Host-synced basic bass and chord pattern",
                             getLocalBounds().withTrimmedTop (334).removeFromTop (24),
                             juce::Justification::centred, 1);
}

void SmartArrangerAudioProcessorEditor::chooseStyleFile()
{
    fileChooser = std::make_unique<juce::FileChooser> ("Choose a Yamaha Style file",
        juce::File(), "*.sty;*.STY;*.prs;*.PRS;*.bcs;*.BCS;*.sst;*.SST;*.scp;*.SCP;*.fps;*.FPS;*.aus;*.AUS");
    juce::Component::SafePointer<SmartArrangerAudioProcessorEditor> safeThis (this);
    fileChooser->launchAsync (juce::FileBrowserComponent::openMode
                                  | juce::FileBrowserComponent::canSelectFiles,
                              [safeThis] (const juce::FileChooser& chooser)
                              {
                                  if (safeThis != nullptr && chooser.getResult().existsAsFile())
                                      safeThis->loadStyleFile (chooser.getResult());
                              });
}

void SmartArrangerAudioProcessorEditor::loadStyleFile (const juce::File& file)
{
    lastRestoreAttemptPath = file.getFullPathName();
    SmartArrangerStyleInfo info;
    juce::String error;
    if (! SmartArrangerStyleFile::inspect (file, info, error))
    {
        const bool retryingSavedStyle = file.getFullPathName() == targetProcessor.getStoredStylePath();
        if (! retryingSavedStyle)
            targetProcessor.clearLoadedStyle();
        loadedStyleInfo = {};
        sectionSelector.clear (juce::dontSendNotification);
        sectionSelector.setVisible (false);
        styleSummary = "Could not load " + file.getFileName();
        styleDetails.clear();
        styleError = error;
        repaint();
        return;
    }

    loadedStyleInfo = std::move (info);
    loadedStylePath = file.getFullPathName();
    sectionSelector.clear (juce::dontSendNotification);
    for (int i = 0; i < static_cast<int> (loadedStyleInfo.sections.size()); ++i)
        sectionSelector.addItem (loadedStyleInfo.sections[static_cast<size_t> (i)].name,
                                 i + 1);
    const bool restoringSameStyle = loadedStylePath == targetProcessor.getStoredStylePath();
    const int sectionToLoad = restoringSameStyle
        ? juce::jlimit (0, static_cast<int> (loadedStyleInfo.sections.size()) - 1,
                        targetProcessor.getStoredStyleSection())
        : 0;
    sectionSelector.setSelectedId (sectionToLoad + 1, juce::dontSendNotification);
    sectionSelector.setVisible (true);
    if (! targetProcessor.setLoadedStyle (loadedStyleInfo, sectionToLoad, error, file))
    {
        targetProcessor.clearLoadedStyle();
        styleSummary = loadedStyleInfo.name + "  |  style parsed";
        styleDetails.clear();
        styleError = error;
        repaint();
        return;
    }

    int usedChannelCount = 0;
    for (int channel = 0; channel < 16; ++channel)
        if ((loadedStyleInfo.usedChannels & (1u << channel)) != 0)
            ++usedChannelCount;

    juce::StringArray sectionNames;
    const int visibleSections = juce::jmin (4, static_cast<int> (loadedStyleInfo.sections.size()));
    for (int i = 0; i < visibleSections; ++i)
        sectionNames.add (loadedStyleInfo.sections[static_cast<size_t> (i)].name);
    if (static_cast<int> (loadedStyleInfo.sections.size()) > visibleSections)
        sectionNames.add ("+" + juce::String (static_cast<int> (loadedStyleInfo.sections.size()) - visibleSections));

    styleSummary = loadedStyleInfo.name + "  |  " + loadedStyleInfo.format + "  |  "
                 + juce::String (loadedStyleInfo.tempo) + " BPM  |  "
                 + juce::String (loadedStyleInfo.numerator) + "/" + juce::String (loadedStyleInfo.denominator);
    styleDetails = sectionNames.joinIntoString ("  ·  ") + "  |  "
                 + juce::String (usedChannelCount) + " MIDI channels  |  "
                 + juce::String (loadedStyleInfo.events.size()) + " MIDI events  |  "
                 + juce::String (loadedStyleInfo.ticksPerQuarter) + " ticks/quarter";
    styleError.clear();
    repaint();
}

void SmartArrangerAudioProcessorEditor::activateStyleSection()
{
    const int selectedId = sectionSelector.getSelectedId();
    if (selectedId <= 0 || loadedStyleInfo.sections.empty())
        return;

    juce::String error;
    if (! targetProcessor.setLoadedStyle (loadedStyleInfo, selectedId - 1, error,
                                          juce::File (loadedStylePath)))
    {
        styleError = error;
        repaint();
        return;
    }

    styleError.clear();
    repaint();
}

void SmartArrangerAudioProcessorEditor::timerCallback()
{
    const auto storedPath = targetProcessor.getStoredStylePath();
    if (storedPath.isNotEmpty() && storedPath != loadedStylePath
        && storedPath != lastRestoreAttemptPath)
    {
        loadStyleFile (juce::File (storedPath));
        return;
    }
    repaint();
}
